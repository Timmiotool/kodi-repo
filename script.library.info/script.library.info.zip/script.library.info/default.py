import xbmc
import xbmcgui
import xbmcaddon
import json

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')

def get_kodi_version():
    return xbmc.getInfoLabel("System.BuildVersion")

def json_rpc_request(method, params=None):
    request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": method
    }
    if params:
        request["params"] = params
    response = xbmc.executeJSONRPC(json.dumps(request))
    return json.loads(response)

def get_counts():
    counts = {}

    # Movies
    result = json_rpc_request("VideoLibrary.GetMovies", {"properties": []})
    counts[ADDON.getLocalizedString(30001)] = len(result.get("result", {}).get("movies", []))

    # TV Shows
    result = json_rpc_request("VideoLibrary.GetTVShows", {"properties": []})
    counts[ADDON.getLocalizedString(30002)] = len(result.get("result", {}).get("tvshows", []))

    # Episodes
    result = json_rpc_request("VideoLibrary.GetEpisodes", {"properties": []})
    counts[ADDON.getLocalizedString(30003)] = len(result.get("result", {}).get("episodes", []))

    # Music - Artists
    result = json_rpc_request("AudioLibrary.GetArtists", {})
    counts["Interpreten"] = len(result.get("result", {}).get("artists", []))

    # Music - Albums
    result = json_rpc_request("AudioLibrary.GetAlbums", {})
    counts["Alben"] = len(result.get("result", {}).get("albums", []))

    # Music - Songs
    result = json_rpc_request("AudioLibrary.GetSongs", {})
    counts["Songs"] = len(result.get("result", {}).get("songs", []))

    return counts

def show_info_dialog():
    kodi_version = get_kodi_version()
    counts = get_counts()

    text = f"[B]Kodi Version:[/B] {kodi_version}\n\n"
    text += "[B]Medienbibliothek:[/B]\n"
    for key, value in counts.items():
        text += f"{key}: {value}\n"

    dialog = xbmcgui.Dialog()
    dialog.textviewer(ADDON_NAME, text)

if __name__ == "__main__":
    show_info_dialog()
