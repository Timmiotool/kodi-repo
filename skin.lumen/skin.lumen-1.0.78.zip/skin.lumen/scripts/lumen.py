"""Lumen background service (started at login).

Up Next ("Play next episode" popup, designs, test function), focus return after playback (home rows and library views),
seek target and progress ring of the player, default views for new lists and the artist slideshow setup.

Runs as a background service (xbmc.service extension of the skin). Options are Lumen skin settings
(Skin.HasSetting / Skin.String) so they can be changed in the Lumen configuration.
"""
import json
import math
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import lumenviews

HOME = 10000
DIALOG_ID = 1109
PLAYER_WINDOWS = (12005, 12006, 12600, 10100, 10101, 10107, 10120, 10130, 10142)  # full screen video/music/visualisation and OSD windows
SKIN_ID = "skin.lumen"
PREFIX = "lumen.upnext."

DEFAULT_TIME = 30       # show the popup this many seconds before the end
DEFAULT_COUNTDOWN = 15  # seconds between popup and automatic start
DEFAULT_STILL = 3       # ask "still watching?" after this many automatic episodes
STILL_WAIT = 30         # seconds to wait for an answer to "still watching?"


def tr(string_id):
    return xbmc.getInfoLabel("$LOCALIZE[%d]" % string_id)


def jsonrpc(method, params=None):
    query = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        query["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(query))).get("result", {}) or {}
    except Exception:
        return {}


def skin_bool(name):
    return xbmc.getCondVisibility("Skin.HasSetting(%s)" % name)


def skin_int(name, default):
    value = xbmc.getInfoLabel("Skin.String(%s)" % name).strip()
    try:
        return int(value)
    except ValueError:
        return default


def set_prop(name, value):
    xbmcgui.Window(HOME).setProperty(PREFIX + name, str(value))


def get_prop(name):
    return xbmcgui.Window(HOME).getProperty(PREFIX + name)


def clear_props():
    for name in ("title", "sub", "show", "thumb", "count", "mode", "progress", "action", "secs", "plot", "se", "etitle"):
        xbmcgui.Window(HOME).clearProperty(PREFIX + name)


def handle(action):
    """Called from the dialog buttons (RunScript(skin.lumen,upnext_<action>)) and the preview buttons in the settings."""
    if action in ("preview", "preview_still"):
        preview(action == "preview_still")
        return
    if get_prop("preview") == "1":
        if action in ("play", "stop"):
            set_prop("preview", "0")   # the preview loop closes the dialog
        return
    set_prop("action", action)


def preview(still):
    """Settings test function: shows the Up Next dialog with the chosen design and the data of a library episode."""
    if get_prop("preview") == "1":
        return
    episode = None
    result = jsonrpc("VideoLibrary.GetEpisodes", {
        "properties": ["season", "episode", "title", "showtitle", "art", "plot"],
        "sort": {"method": "lastplayed", "order": "descending"}, "limits": {"start": 0, "end": 1}})
    episodes = result.get("episodes") or []
    if episodes:
        episode = episodes[0]
    else:
        episode = {"season": 1, "episode": 5, "title": "Example", "showtitle": "Example series",
                   "plot": "Example description of the next episode.", "art": {}}
    art = episode.get("art", {})
    mode = "still" if still else "next"
    countdown = skin_int("upnext.count", DEFAULT_COUNTDOWN)
    auto = not skin_bool("upnext.noauto")
    set_prop("preview", "1")
    set_prop("thumb", art.get("thumb") or art.get("tvshow.fanart") or art.get("tvshow.poster", ""))
    set_prop("show", episode.get("showtitle", ""))
    set_prop("title", "S%02dE%02d  %s" % (episode.get("season", 0), episode.get("episode", 0), episode.get("title", "")))
    set_prop("se", "S%d:E%d" % (episode.get("season", 0), episode.get("episode", 0)))
    set_prop("etitle", episode.get("title", ""))
    set_prop("plot", episode.get("plot", ""))
    set_prop("mode", mode)
    set_prop("sub", tr(32764) if still else tr(32760))
    set_prop("action", "")
    set_prop("count", "")
    set_prop("progress", 0)
    set_prop("secs", "")
    xbmc.executebuiltin("ActivateWindow(%d)" % DIALOG_ID)
    monitor = xbmc.Monitor()
    t0 = time.time()
    limit = STILL_WAIT if still else (countdown if auto else 20)
    while get_prop("preview") == "1" and not monitor.abortRequested():
        waited = time.time() - t0
        if waited > 2 and not xbmc.getCondVisibility("Window.IsActive(%d)" % DIALOG_ID):
            break   # closed with Back
        if waited >= limit:
            break
        left = max(0, int(math.ceil(limit - waited)))
        if still:
            set_prop("count", tr(32766) % left)
            set_prop("progress", int(100 * (1 - waited / limit)))
        elif auto:
            set_prop("count", tr(32763) % left)
            set_prop("secs", left)
            set_prop("progress", int(100 * max(0.0, 1 - waited / max(1, limit))))
        monitor.waitForAbort(0.1)
    if xbmc.getCondVisibility("Window.IsActive(%d)" % DIALOG_ID):
        xbmc.executebuiltin("Dialog.Close(%d)" % DIALOG_ID)
    clear_props()
    xbmcgui.Window(HOME).clearProperty(PREFIX + "preview")


class UpNextPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.auto_started = False
        self.auto_count = 0
        self.home_item = None      # item of a home widget that was played from the home screen
        self.home_pending = None   # same item, waiting for the home screen to come back
        self.home_last = None      # last focused home widget item (updated while the home screen is shown)
        self.home_stamp = 0.0
        self.lib_last = None       # focused item of a library view (updated while the view is shown)
        self.lib_item = None       # item of a library view that was played from there
        self.lib_pending = None    # same item, waiting for the view to come back
        self.lib_stamp = 0.0
        self.lib_play = None       # (dbtype, dbid) of the item that played last

    def remember_home_item(self):
        """Called often: remember the focused item of the home widgets (the play start may happen behind a dialog)."""
        window = xbmcgui.getCurrentWindowId()
        if window == HOME:
            if xbmcgui.getCurrentWindowDialogId() != 9999:
                return  # a dialog (e.g. context menu) is open above the home screen: keep what we know
            cid = xbmcgui.Window(HOME).getProperty("HomeLast")
            on_row = cid.isdigit() and xbmc.getCondVisibility("Control.HasFocus(%s)" % cid)
            # the Play button above the rows plays the item that is highlighted in the last row
            on_button = cid.isdigit() and xbmc.getCondVisibility(
                "Control.HasFocus(9290) | Control.HasFocus(9291) | Control.HasFocus(9292) | Control.HasFocus(9293)")
            if on_row or on_button:
                prefix = "Container(%s).ListItem" % cid
                self.home_last = {"cid": int(cid),
                                  "dbid": xbmc.getInfoLabel(prefix + ".DBID"),
                                  "dbtype": xbmc.getInfoLabel(prefix + ".DBType"),
                                  "label": xbmc.getInfoLabel(prefix + ".Label")}
            else:
                self.home_last = None
        elif window not in (12005, 12006, 10107, 10100, 10101):
            self.home_last = None  # some other window: not started from home

    def remember_lib_item(self):
        """Remember the focused item of the library view (list/poster views 50-69) so that it can be focused again."""
        window = xbmcgui.getCurrentWindowId()
        if window == HOME or window in PLAYER_WINDOWS:
            if window == HOME:
                self.lib_last = None
            return
        if xbmcgui.getCurrentWindowDialogId() != 9999:
            return  # a dialog (context menu, resume question) is open above the view: keep what we know
        for cid in range(50, 70):
            if xbmc.getCondVisibility("Control.HasFocus(%d)" % cid):
                prefix = "Container(%d).ListItem" % cid
                current = xbmc.getInfoLabel("Container(%d).CurrentItem" % cid)
                if not current.isdigit() or int(current) < 1:
                    break
                self.lib_last = {"window": window, "cid": cid, "index": int(current) - 1,
                                 "dbid": xbmc.getInfoLabel(prefix + ".DBID"),
                                 "dbtype": xbmc.getInfoLabel(prefix + ".DBType"),
                                 "label": xbmc.getInfoLabel(prefix + ".Label")}
                return
        if self.lib_last and self.lib_last["window"] != window:
            self.lib_last = None
    def onPlayBackStarted(self):
        if xbmc.getSkinDir() != SKIN_ID:
            return
        if self.home_last:
            self.home_item = self.home_last
        elif self.home_item:
            pass  # the next episode replaced the running one (no stop in between): same origin
        elif self.home_pending and time.time() - self.home_stamp < 10:
            self.home_item = self.home_pending  # the next episode started by itself: same origin
        else:
            self.home_item = None
        self.home_last = None
        self.home_pending = None
        if self.lib_last:
            self.lib_item = self.lib_last
        elif self.lib_item:
            pass  # the next item replaced the running one: same origin
        elif self.lib_pending and time.time() - self.lib_stamp < 10:
            self.lib_item = self.lib_pending
        else:
            self.lib_item = None
        self.lib_last = None
        self.lib_pending = None
        self.lib_play = None

    def onPlayBackStopped(self):
        if self.home_item:
            self.home_pending = self.home_item
            self.home_stamp = time.time()
        self.home_item = None
        if self.lib_item:
            self.lib_pending = self.lib_item
            self.lib_stamp = time.time()
        self.lib_item = None

    def onPlayBackEnded(self):
        self.onPlayBackStopped()
    def onAVStarted(self):
        if self.lib_item:
            played = jsonrpc("Player.GetItem", {"playerid": 1 if self.isPlayingVideo() else 0}).get("item", {})
            if played.get("id", -1) >= 0:
                self.lib_play = (played.get("type", ""), str(played["id"]))
        if self.auto_started:
            self.auto_count += 1
        else:
            self.auto_count = 0
        self.auto_started = False

BAR_WIDTH = 1720        # width of the seek bar in the skin (pixels)
BAR_STEP = 17           # coarse step of the marker animation in the skin


def parse_time(text):
    """'1:02:03' / '02:03' -> seconds, None if it is not a time."""
    try:
        parts = [int(p) for p in text.strip().split(":")]
    except ValueError:
        return None
    seconds = 0
    for part in parts:
        seconds = seconds * 60 + part
    return seconds


def clear_seek_target():
    window = xbmcgui.Window(HOME)
    window.clearProperty(PREFIX + "seekc")
    window.clearProperty(PREFIX + "seekf")


def update_seek_target(player, enabled):
    """While the user is seeking (e.g. pressing a skip key several times) show the target position on the bar."""
    if not enabled or not player.isPlayingVideo():
        clear_seek_target()
        return
    if not xbmc.getCondVisibility("Player.Seeking | Player.HasPerformedSeek(2)"):
        clear_seek_target()
        return
    target = parse_time(xbmc.getInfoLabel("Player.SeekTime"))
    try:
        total = player.getTotalTime()
    except Exception:
        total = 0
    if target is None or total <= 0:
        clear_seek_target()
        return
    pixels = max(0, min(BAR_WIDTH, int(BAR_WIDTH * target / total)))
    set_prop("seekc", pixels // BAR_STEP)
    set_prop("seekf", pixels % BAR_STEP)

RING_FRAMES = 72
RING_SECONDS = 14.0


def update_ring():
    """Frame animation of the logo ring (a rotate animation would turn the circle into an ellipse on non 16:9 screens)."""
    if xbmc.getCondVisibility("Window.IsActive(1110) | Control.HasFocus(108) | Control.HasFocus(4010)"):
        frame = int((time.time() % RING_SECONDS) / RING_SECONDS * RING_FRAMES) % RING_FRAMES
        set_prop("ringtex", "special://skin/media/ring_%02d.png" % frame)

# Artist Slideshow settings of the Lumen reference installation (applied once after installation)
SLIDESHOW_SETTINGS = {
    "fanarttv": "true",
    "theaudiodb": "true",
    "ai_theaudiodb": "true",
    "ai_lastfm": "true",
    "language": "16",
    "ab_theaudiodb": "true",
    "ab_lastfm": "true",
    "sa_lastfm": "true",
}


def configure_artistslideshow():
    """Apply the reference settings to Artist Slideshow once, if it is installed and was not configured by Lumen before."""
    if xbmc.getCondVisibility("Skin.HasSetting(lumen.asinit)"):
        return
    if not xbmc.getCondVisibility("System.HasAddon(script.artistslideshow)"):
        return
    try:
        addon = xbmcaddon.Addon("script.artistslideshow")
        for key, value in SLIDESHOW_SETTINGS.items():
            addon.setSetting(key, value)
    except Exception:
        return
    xbmc.executebuiltin("Skin.SetBool(lumen.asinit)")

SLIDESHOW = {"started": False}


_fresh = {"seen": False}


def apply_views_after_first_init():
    """On a fresh installation the skin defaults are set when the first window loads (lumen.init false -> true).
    Right after that, switch all saved Lumen views to the default views."""
    if not skin_bool("lumen.init"):
        _fresh["seen"] = True
    elif _fresh["seen"]:
        _fresh["seen"] = False
        lumenviews.apply_all()

def apply_default_view():
    """Give new paths the Lumen standard view (see lumenviews.py)."""
    window = xbmcgui.getCurrentWindowId()
    if window in lumenviews.DEFAULT_VIEWS:
        lumenviews.apply(window)


def update_slideshow():
    """Start Artist Slideshow while music from the library plays, so the home screen has images before the player is opened."""
    if not xbmc.getCondVisibility("Player.HasAudio"):
        SLIDESHOW["started"] = False
        return
    if SLIDESHOW["started"]:
        return
    if xbmc.getCondVisibility("!Player.HasVideo + !String.IsEmpty(MusicPlayer.DBID) + !Skin.HasSetting(music.nofanart) + "
                              "!Skin.HasSetting(home.nonowplaying) + System.AddonIsEnabled(script.artistslideshow)"):
        SLIDESHOW["started"] = True
        xbmc.executebuiltin("RunScript(script.artistslideshow)")

def current_episode():
    """Info about the playing episode or None (only library episodes are handled)."""
    result = jsonrpc("Player.GetItem", {"playerid": 1, "properties": [
        "tvshowid", "season", "episode", "showtitle", "title", "playcount"]})
    item = result.get("item", {})
    if item.get("type") != "episode" or item.get("id", -1) < 0 or item.get("tvshowid", -1) < 0:
        return None
    return item


def find_next(item, allow_next_season):
    result = jsonrpc("VideoLibrary.GetEpisodes", {
        "tvshowid": item["tvshowid"],
        "properties": ["season", "episode", "title", "showtitle", "art", "playcount", "runtime", "plot"],
        "sort": {"method": "episode", "order": "ascending"}})
    here = (item.get("season", 0), item.get("episode", 0))
    best = None
    for ep in result.get("episodes", []):
        key = (ep.get("season", 0), ep.get("episode", 0))
        if key <= here:
            continue
        if ep.get("season", 0) == 0 and here[0] != 0:
            continue
        if not allow_next_season and key[0] != here[0]:
            continue
        if best is None or key < (best.get("season", 0), best.get("episode", 0)):
            best = ep
    return best


def home_item_focused(item):
    """True when the focus is on the played item of the home row."""
    cid = item["cid"]
    if not xbmc.getCondVisibility("Control.HasFocus(%d)" % cid):
        return False
    prefix = "Container(%d).ListItem" % cid
    if item["dbid"] and item["dbid"] != "0":
        return (xbmc.getInfoLabel(prefix + ".DBID") == item["dbid"]
                and xbmc.getInfoLabel(prefix + ".DBType") == item["dbtype"])
    return xbmc.getInfoLabel(prefix + ".Label") == item["label"]

def focus_home_item(item):
    """Put the focus back on the item of the home widget that was played (it may have moved in the list)."""
    cid = item["cid"]
    count = int(xbmc.getInfoLabel("Container(%d).NumItems" % cid) or 0)
    found = -1
    for index in range(count):
        prefix = "Container(%d).ListItemAbsolute(%d)" % (cid, index)
        if item["dbid"] and item["dbid"] != "0":
            if (xbmc.getInfoLabel(prefix + ".DBID") == item["dbid"]
                    and xbmc.getInfoLabel(prefix + ".DBType") == item["dbtype"]):
                found = index
                break
        elif xbmc.getInfoLabel(prefix + ".Label") == item["label"]:
            found = index
            break
    if found >= 0:
        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, found))
    return found >= 0

def focus_lib_item(item, play):
    """Focus the library view item that was played last and scroll the list to it."""
    cid = item["cid"]
    count = int(xbmc.getInfoLabel("Container(%d).NumItems" % cid) or 0)
    wanted = []
    if play:
        wanted.append(("dbid", play))
    if item["dbid"] and item["dbid"] != "0":
        wanted.append(("dbid", (item["dbtype"], item["dbid"])))
    found = -1
    for kind, (dbtype, dbid) in wanted:
        for index in range(count):
            prefix = "Container(%d).ListItemAbsolute(%d)" % (cid, index)
            if (xbmc.getInfoLabel(prefix + ".DBID") == dbid
                    and xbmc.getInfoLabel(prefix + ".DBType") == dbtype):
                found = index
                break
        if found >= 0:
            break
    if found < 0:
        for index in range(count):
            if xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Label" % (cid, index)) == item["label"]:
                found = index
                break
    if found < 0 and item["index"] < count:
        found = item["index"]
    if found >= 0:
        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, found))

NETWORK_SCHEMES = ("smb://", "nfs://", "ftp://", "sftp://", "webdav://", "dav://", "upnp://")
MEDIA_EXTENSIONS = (".mkv", ".mp4", ".avi", ".m4v", ".mov", ".ts", ".m2ts", ".wmv", ".mpg", ".mpeg", ".iso", ".mp3", ".flac")


def _wake_source(path, depth=0):
    """Read a few bytes of a media file below a network source: only a real file read makes the NAS spin up its disks."""
    try:
        dirs, files = xbmcvfs.listdir(path)
    except Exception:
        return False
    for name in files:
        if name.lower().endswith(MEDIA_EXTENSIONS):
            try:
                handle = xbmcvfs.File(path + name)
                try:
                    handle.readBytes(4096)
                finally:
                    handle.close()
                return True
            except Exception as error:
                xbmc.log("Lumen: NAS wake could not read %s: %s" % (path + name, error), xbmc.LOGINFO)
                return False
    if depth < 3:
        for name in dirs[:6]:
            if _wake_source(path + name + "/", depth + 1):
                return True
    return False


def wake_nas():
    """Skin option Wake up NAS disks at start: touches every network video/music source once (background thread)."""
    sources = []
    for media in ("video", "music"):
        result = jsonrpc("Files.GetSources", {"media": media})
        for source in result.get("sources", []):
            path = source.get("file", "")
            if path.lower().startswith(NETWORK_SCHEMES) and not path.startswith("multipath://"):
                sources.append(path if path.endswith("/") else path + "/")
    done = set()
    for path in sources:
        if path in done:
            continue
        done.add(path)
        started = time.time()
        woke = _wake_source(path)
        xbmc.log("Lumen: NAS wake %s -> %s (%.1f s)" % (path, "read ok" if woke else "no file read", time.time() - started), xbmc.LOGINFO)


def start_nas_wake():
    thread = threading.Thread(target=wake_nas, name="lumen-nas-wake")
    thread.daemon = True
    thread.start()


def run():
    monitor = xbmc.Monitor()
    player = UpNextPlayer()
    xbmcgui.Window(HOME).setProperty(PREFIX + "alive", "1")
    nas_woken = False
    state = {"key": None, "next": None, "shown": False, "dismissed": False, "t0": 0.0, "mode": None, "hold": False}

    def close_dialog():
        if xbmc.getCondVisibility("Window.IsActive(%d)" % DIALOG_ID):
            xbmc.executebuiltin("Dialog.Close(%d)" % DIALOG_ID)
        clear_props()
        state["shown"] = False

    def reset():
        if state["shown"]:
            close_dialog()
        state.update({"key": None, "next": None, "shown": False, "dismissed": False, "mode": None, "hold": False})

    def play_next(auto):
        episode = state["next"]
        item = state.get("item") or {}
        close_dialog()
        state["dismissed"] = True
        if not episode:
            return
        try:
            total = player.getTotalTime()
            if total > 0 and player.getTime() / total < 0.9 and item.get("id", -1) >= 0:
                jsonrpc("VideoLibrary.SetEpisodeDetails", {
                    "episodeid": item["id"], "playcount": item.get("playcount", 0) + 1,
                    "resume": {"position": 0, "total": 0}})
        except Exception:
            pass
        player.auto_started = auto
        jsonrpc("Player.Open", {"item": {"episodeid": episode["episodeid"]}, "options": {"resume": False}})

    tick = 0
    while not monitor.waitForAbort(0.1):
        if xbmc.getSkinDir() == SKIN_ID:
            update_ring()
        if tick % 2 == 0:
            update_seek_target(player, xbmc.getSkinDir() == SKIN_ID and not skin_bool("video.noseekmark"))
        tick += 1
        if xbmc.getSkinDir() == SKIN_ID and tick % 3 == 0:
            player.remember_home_item()
        if xbmc.getSkinDir() == SKIN_ID and tick % 3 == 0:
            player.remember_lib_item()
        if player.lib_pending and xbmc.getSkinDir() == SKIN_ID:
            pend = player.lib_pending
            if (xbmcgui.getCurrentWindowId() == pend["window"] and xbmcgui.getCurrentWindowDialogId() == 9999
                    and not player.isPlaying()):
                if "since" not in pend:
                    pend["since"] = tick
                    pend["idle0"] = xbmc.getGlobalIdleTime()
                age = tick - pend["since"]
                if xbmc.getGlobalIdleTime() < pend["idle0"] + age * 0.1 - 0.8:
                    player.lib_pending = None   # the user pressed a key meanwhile: do not interfere
                elif age == 8:
                    # images of the played item can fail to load after a long playback (the red cross): reload the list once
                    xbmc.executebuiltin("Container.Refresh")
                elif age in (4, 12, 30):
                    if not (pend.get("dbtype") in ("episode", "season", "tvshow")
                            and xbmc.getCondVisibility("Skin.HasSetting(series.nolast)")):
                        focus_lib_item(pend, player.lib_play)
                elif age > 31:
                    player.lib_pending = None
            elif player.isPlaying() or time.time() - player.lib_stamp > 90:
                player.lib_pending = None
        if player.home_pending and xbmc.getSkinDir() == SKIN_ID:
            if xbmc.getCondVisibility("Window.IsActive(home)") and xbmcgui.getCurrentWindowDialogId() == 9999:
                pend = player.home_pending
                if "since" not in pend:
                    pend["since"] = tick
                    pend["idle0"] = xbmc.getGlobalIdleTime()
                    pend["good"] = 0
                age = tick - pend["since"]
                if xbmc.getGlobalIdleTime() < pend["idle0"] + age * 0.1 - 0.8:
                    player.home_pending = None   # the user pressed a key meanwhile: do not interfere
                elif age >= 4:
                    # keep the focus on the item while the widgets reload (the item may move in the list)
                    if home_item_focused(pend):
                        pend["good"] += 1
                    else:
                        pend["good"] = 0
                        focus_home_item(pend)
                    if pend["good"] >= 15 or age > 150:
                        player.home_pending = None
            elif player.isPlayingVideo() or player.isPlayingAudio():
                player.home_pending = None
        # while the Up Next popup is shown the countdown is updated on every pass (1 s steps would skip numbers)
        if tick % 10 == 5 and xbmc.getSkinDir() == SKIN_ID:   # option Wake up NAS disks: once per Kodi start / switch-on
            wake = skin_bool("nas.wake")
            if wake and not nas_woken:
                nas_woken = True
                start_nas_wake()
            elif not wake:
                nas_woken = False
        slow = tick % 10 == 0
        fast = state["shown"] and not state["dismissed"]
        if not slow and not fast:
            continue
        if slow and xbmc.getSkinDir() == SKIN_ID:
            configure_artistslideshow()
            update_slideshow()
            apply_views_after_first_init()
            apply_default_view()
        if xbmc.getSkinDir() != SKIN_ID or skin_bool("upnext.off") or not player.isPlayingVideo():
            if state["key"] is not None:
                reset()
            continue
        try:
            total = player.getTotalTime()
            position = player.getTime()
        except Exception:
            continue
        if total <= 0:
            continue
        item = current_episode() if slow else state.get("item")
        if not item:
            if state["key"] is not None:
                reset()
            continue
        key = (item["id"], xbmc.getInfoLabel("Player.Filenameandpath")) if slow else state["key"]
        if state["key"] != key:
            reset()
            state["key"] = key
            state["item"] = item
            state["next"] = find_next(item, not skin_bool("upnext.noseason"))
        episode = state["next"]
        if not episode:
            continue

        remaining = total - position
        show_before = skin_int("upnext.time", DEFAULT_TIME)
        countdown = skin_int("upnext.count", DEFAULT_COUNTDOWN)
        still_after = skin_int("upnext.still", DEFAULT_STILL)
        auto = not skin_bool("upnext.noauto")

        if state["dismissed"] or remaining > show_before or remaining < 0.5:
            if state["shown"] and remaining > show_before + 3:   # user seeked back
                close_dialog()
                state["dismissed"] = False
            continue

        ask_still = auto and still_after > 0 and player.auto_count + 1 >= still_after
        if not state["shown"]:
            state["shown"] = True
            state["t0"] = time.time()
            state["mode"] = "still" if ask_still else "next"
            art = episode.get("art", {})
            set_prop("thumb", art.get("thumb") or art.get("tvshow.fanart") or art.get("tvshow.poster", ""))
            set_prop("show", episode.get("showtitle", ""))
            set_prop("title", "S%02dE%02d  %s" % (episode.get("season", 0), episode.get("episode", 0), episode.get("title", "")))
            set_prop("se", "S%d:E%d" % (episode.get("season", 0), episode.get("episode", 0)))
            set_prop("etitle", episode.get("title", ""))
            set_prop("plot", episode.get("plot", ""))
            set_prop("mode", state["mode"])
            set_prop("sub", tr(32764) if state["mode"] == "still" else tr(32760))
            set_prop("action", "")
            xbmc.executebuiltin("ActivateWindow(%d)" % DIALOG_ID)
        elif not xbmc.getCondVisibility("Window.IsActive(%d)" % DIALOG_ID):
            state["dismissed"] = True       # popup closed with Back: keep watching, no automatic start
            clear_props()
            state["shown"] = False
            continue

        action = get_prop("action")
        if action == "more":   # "More info" was opened: no automatic start while reading
            state["hold"] = True
            set_prop("action", "")
            action = ""
        if action == "play":
            player.auto_count = 0
            play_next(False)
            continue
        if action == "stop":
            close_dialog()
            state["dismissed"] = True
            player.stop()
            continue

        waited = time.time() - state["t0"]
        if state["mode"] == "still":
            left = max(0, int(math.ceil(STILL_WAIT - waited)))
            set_prop("count", tr(32766) % left)
            set_prop("progress", int(100 * (1 - waited / STILL_WAIT)))
            if waited >= STILL_WAIT or remaining < 1.5:
                close_dialog()
                state["dismissed"] = True        # nobody answered: do not start the next episode
        else:
            left = max(0, int(math.ceil(countdown - waited)))
            set_prop("secs", left)
            if auto and not state["hold"]:
                set_prop("count", tr(32763) % left)
                set_prop("progress", int(100 * max(0.0, 1 - waited / max(1, countdown))))
                if waited >= countdown or remaining < 1.5:
                    play_next(True)
            else:
                set_prop("count", "")
                set_prop("progress", 0)


if __name__ == "__main__":
    run()