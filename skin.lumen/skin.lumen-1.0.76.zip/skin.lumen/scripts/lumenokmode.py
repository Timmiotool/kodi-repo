"""Library OK key: maps the Lumen option to Kodi's own setting "Default select action" (myvideos.selectaction).

Kodi decides what happens when a movie or episode is selected in the library. A skin cannot override that, so the
Lumen option writes the Kodi setting. The value Kodi had before is remembered (skin string click.lib.orig) and
restored when the option goes back to Standard or when Lumen is reset.
"""
import json

import xbmc

SETTING = "myvideos.selectaction"
# Lumen value -> Kodi value (0 = choose, 1 = play, 2 = resume, 3 = info)
MODES = {"play": 1, "info": 3, "choose": 0}


def _rpc(method, params):
    return json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))


def _get():
    return _rpc("Settings.GetSettingValue", {"setting": SETTING}).get("result", {}).get("value")


def _set(value):
    _rpc("Settings.SetSettingValue", {"setting": SETTING, "value": int(value)})


def apply():
    mode = xbmc.getInfoLabel("Skin.String(click.lib)")
    orig = xbmc.getInfoLabel("Skin.String(click.lib.orig)")
    if mode in MODES:
        if not orig.isdigit():
            current = _get()
            if current is not None:
                xbmc.executebuiltin("Skin.SetString(click.lib.orig,%d)" % int(current))
        _set(MODES[mode])
    else:
        restore()


def restore():
    """Give Kodi back the value it had before Lumen changed it."""
    orig = xbmc.getInfoLabel("Skin.String(click.lib.orig)")
    if orig.isdigit():
        _set(orig)
        xbmc.executebuiltin("Skin.Reset(click.lib.orig)")