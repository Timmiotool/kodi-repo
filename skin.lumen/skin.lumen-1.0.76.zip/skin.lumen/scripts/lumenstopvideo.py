"""Stop the video after the fullscreen video window was left (option: stop when leaving the video player)."""
import xbmc


def stop_video():
    monitor = xbmc.Monitor()
    # let the window change finish first; stopping inside the window unload leaves the picture frozen
    waited = 0
    while xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)") and waited < 20:
        monitor.waitForAbort(0.1)
        waited += 1
    monitor.waitForAbort(0.4)
    if xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
        return  # fullscreen is shown again (e.g. only a short window change): keep playing
    if xbmc.getCondVisibility("Skin.HasSetting(video.stoponexit) + Player.HasVideo"):
        xbmc.executebuiltin("PlayerControl(Stop)")