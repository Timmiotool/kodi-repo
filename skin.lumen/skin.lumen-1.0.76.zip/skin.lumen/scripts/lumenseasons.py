"""Seasons list: focus the season of the episode played most recently (also partly watched), once per opened show."""
import re
import json

import xbmc
import xbmcgui

HOME = xbmcgui.Window(10000)
PROP = "lumen.seasonpath"


def _rpc(method, params):
    request = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request)))


def focus(container_id):
    if xbmc.getCondVisibility("Skin.HasSetting(series.nolast)"):
        return  # option Focus in series: Standard
    path = xbmc.getInfoLabel("Container.FolderPath")
    match = re.match(r"^videodb://tvshows/titles/(\d+)/?(\?.*)?$", path or "")
    if not match:
        return
    # run only once per opened show; going back from the episodes keeps the position Kodi restores
    if HOME.getProperty(PROP) == path:
        return
    result = _rpc("VideoLibrary.GetEpisodes", {"tvshowid": int(match.group(1)),
                                               "properties": ["season", "lastplayed"],
                                               "sort": {"method": "lastplayed", "order": "descending"},
                                               "limits": {"start": 0, "end": 1}})
    episodes = (result.get("result") or {}).get("episodes") or []
    played = [e for e in episodes if e.get("lastplayed") and e.get("season", 0) >= 0]
    HOME.setProperty(PROP, path)
    if not played:
        return
    target = str(played[0]["season"])
    cid = int(container_id)
    count = 0
    for _ in range(30):  # wait until the list is filled
        count = int(xbmc.getInfoLabel("Container.NumItems") or 0)
        if count > 1 and xbmc.getInfoLabel("Container.FolderPath") == path:
            break
        xbmc.sleep(100)
    for index in range(count + 1):  # NumItems does not count the parent ("..") item
        if xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Season" % (cid, index)) == target:
            xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, index))
            return


def focus_episode():
    """Started by the click on a series on the home screen (option home.nooverview off): if Kodi reopens an episode
    list, focus the episode played most recently."""
    if xbmc.getCondVisibility("Skin.HasSetting(series.nolast)"):
        return  # option Focus in series: Standard
    path = ""
    match = None
    for _ in range(60):  # wait until the videos window shows a list (up to 6 s)
        path = xbmc.getInfoLabel("Container.FolderPath")
        if re.match(r"^videodb://tvshows/titles/(\d+)/?(\?.*)?$", path or ""):
            return  # season overview: nothing to do here
        match = re.match(r"^videodb://tvshows/titles/(\d+)/(-?\d+)/", path or "")
        if match and int(xbmc.getInfoLabel("Container.NumItems") or 0) > 1:
            break
        match = None
        xbmc.sleep(100)
    if not match:
        return
    result = _rpc("VideoLibrary.GetEpisodes", {"tvshowid": int(match.group(1)),
                                               "properties": ["season", "lastplayed"],
                                               "sort": {"method": "lastplayed", "order": "descending"},
                                               "limits": {"start": 0, "end": 1}})
    episodes = (result.get("result") or {}).get("episodes") or []
    if not episodes or not episodes[0].get("lastplayed") or str(episodes[0].get("season")) != match.group(2):
        return
    wanted = str(episodes[0]["episodeid"])
    cid = 0
    for view in (57, 52, 56, 50, 51, 53, 54, 55):
        if xbmc.getCondVisibility("Control.IsVisible(%d)" % view):
            cid = view
            break
    if not cid:
        return
    count = int(xbmc.getInfoLabel("Container.NumItems") or 0)
    for index in range(count + 1):  # NumItems does not count the parent ("..") item
        prefix = "Container(%d).ListItemAbsolute(%d)" % (cid, index)
        if xbmc.getInfoLabel(prefix + ".DBID") == wanted and xbmc.getInfoLabel(prefix + ".DBType") == "episode":
            xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, index))
            return
