import re
import sys
import json

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon("skin.lumen")
ADDON_NAME = ADDON.getAddonInfo('name')
HOME = xbmcgui.Window(10000)


def json_rpc_request(method, params=None):
    request = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params:
        request["params"] = params
    return json.loads(xbmc.executeJSONRPC(json.dumps(request)))


def total(method, key, extra=None):
    """Return the number of items without loading them (limits.total)."""
    params = {"limits": {"start": 0, "end": 1}}
    if extra:
        params.update(extra)
    result = json_rpc_request(method, params)
    return int(result.get("result", {}).get("limits", {}).get("total", 0))


UNWATCHED = {"filter": {"field": "playcount", "operator": "is", "value": "0"}}


def get_counts():
    counts = {}
    counts["movies"] = total("VideoLibrary.GetMovies", "movies")
    counts["movies_unwatched"] = total("VideoLibrary.GetMovies", "movies", UNWATCHED)
    counts["tvshows"] = total("VideoLibrary.GetTVShows", "tvshows")
    counts["episodes"] = total("VideoLibrary.GetEpisodes", "episodes")
    counts["episodes_unwatched"] = total("VideoLibrary.GetEpisodes", "episodes", UNWATCHED)
    counts["artists"] = total("AudioLibrary.GetArtists", "artists")
    counts["albums"] = total("AudioLibrary.GetAlbums", "albums")
    counts["songs"] = total("AudioLibrary.GetSongs", "songs")
    return counts


def set_properties():
    """Publish the counts as Window(Home) properties for skins (RunScript(script.library.info,props))."""
    HOME.clearProperty("LibraryInfo.Ready")
    for key, value in get_counts().items():
        HOME.setProperty("LibraryInfo." + key, str(value))
    HOME.setProperty("LibraryInfo.Ready", "true")


VCODEC = {"hevc": "H.265", "h265": "H.265", "h264": "H.264", "avc1": "H.264", "mpeg2video": "MPEG-2",
          "mpeg4": "MPEG-4", "xvid": "MPEG-4", "divx": "MPEG-4", "vc1": "VC-1", "wmv3": "VC-1",
          "av1": "AV1", "vp9": "VP9", "mpeg1video": "MPEG-1"}
ACODEC = {"eac3": "DOLBY DIGITAL+", "ac3": "DOLBY DIGITAL", "truehd": "DOLBY TRUEHD", "dtshd_ma": "DTS-HD MA",
          "dtshd_hra": "DTS-HD HRA", "dca": "DTS", "dts": "DTS", "aac": "AAC", "flac": "FLAC", "mp3": "MP3",
          "mp2": "MP2", "opus": "OPUS", "vorbis": "VORBIS", "pcm_s16le": "PCM", "wmapro": "WMA PRO"}
CHANNELS = {1: "1.0", 2: "2.0", 3: "2.1", 6: "5.1", 7: "6.1", 8: "7.1"}


def video_res_label(width, height):
    if width >= 7000 or height >= 4000:
        return "8K UHD"
    if width >= 3000 or height >= 1900:
        return "4K UHD"
    if width >= 1800 or height >= 1000:
        return "1080 HD"
    if width >= 1200 or height >= 700:
        return "720 HD"
    return "SD" if height else ""


def hms(seconds):
    seconds = int(seconds or 0)
    return "%02d:%02d:%02d" % (seconds // 3600, seconds % 3600 // 60, seconds % 60) if seconds else ""


def favourite_info(raw):
    """Look up video facts for a favourite (it only carries the file path) and publish them for the skin."""
    from urllib.parse import unquote
    props = ("Duration", "Codec", "Res", "Aspect", "Audio", "Channels")
    for key in props:
        HOME.clearProperty("FavInfo." + key)
    path = unquote(unquote(raw))
    if "PlayMedia(" in path:
        inner = path.split("PlayMedia(", 1)[1]
        quoted = re.match(r'\s*"([^"]*)"', inner)
        # the action may carry extra arguments after the quoted path (e.g. ,playlist_type_hint=1)
        path = quoted.group(1) if quoted else inner.split(",", 1)[0].rstrip(") ")
    name = path.replace("\\", "/").rstrip("/").rsplit("/", 1)[-1]
    if not name:
        return
    details = None
    label = xbmc.getInfoLabel("ListItem.Label")
    lookups = [("VideoLibrary.GetMovies", "movies", "filename", name),
               ("VideoLibrary.GetEpisodes", "episodes", "filename", name)]
    if label:
        # the library may know the file under another name: fall back to the title
        lookups.append(("VideoLibrary.GetMovies", "movies", "title", label))
    for method, key, field, value in lookups:
        result = json_rpc_request(method, {"properties": ["runtime", "streamdetails"], "limits": {"start": 0, "end": 1},
                                           "filter": {"field": field, "operator": "is", "value": value}})
        found = result.get("result", {}).get(key)
        if found:
            details = found[0]
            break
    if not details or xbmc.getInfoLabel("ListItem.FileNameAndPath") != raw:
        return
    stream = details.get("streamdetails", {})
    video = (stream.get("video") or [{}])[0]
    audio = (stream.get("audio") or [{}])[0]
    values = {
        "Duration": hms(details.get("runtime") or video.get("duration")),
        "Codec": VCODEC.get(video.get("codec", ""), video.get("codec", "").upper()),
        "Res": video_res_label(video.get("width", 0), video.get("height", 0)),
        "Aspect": ("%.2f:1" % video["aspect"]).replace(".00", "") if video.get("aspect") else "",
        "Audio": ACODEC.get(audio.get("codec", ""), audio.get("codec", "").upper()),
        "Channels": CHANNELS.get(audio.get("channels", 0), str(audio.get("channels", "")) if audio.get("channels") else ""),
    }
    for key, value in values.items():
        if value:
            HOME.setProperty("FavInfo." + key, value)


def favourite_watch():
    """Keep the media chips of the favourites window up to date while it is open."""
    if HOME.getProperty("FavInfo.Watching") == "1":
        return
    HOME.setProperty("FavInfo.Watching", "1")
    monitor = xbmc.Monitor()
    last = None
    try:
        while not monitor.abortRequested() and xbmc.getCondVisibility("Window.IsActive(favouritesbrowser)"):
            current = xbmc.getInfoLabel("ListItem.FileNameAndPath")
            if current != last:
                last = current
                if current:
                    favourite_info(current)
            monitor.waitForAbort(0.2)
    finally:
        HOME.clearProperty("FavInfo.Watching")
        for key in ("Duration", "Codec", "Res", "Aspect", "Audio", "Channels"):
            HOME.clearProperty("FavInfo." + key)

def show_changelog(addon_id):
    """Show the changelog.txt of an installed add-on in a text viewer."""
    text = ""
    try:
        addon = xbmcaddon.Addon(addon_id)
        path = addon.getAddonInfo("path")
        lang = xbmc.getLanguage(xbmc.ISO_639_1)
        for name in ("changelog-%s.txt" % lang, "changelog.txt", "changelog.md", "CHANGELOG.md"):
            filename = path.rstrip("/\\") + "/" + name
            if xbmcvfs.exists(filename):
                f = xbmcvfs.File(filename)
                try:
                    text = f.read()
                finally:
                    f.close()
                if text:
                    break
        title = addon.getAddonInfo("name")
    except RuntimeError:
        title = addon_id
    if not text:
        xbmcgui.Dialog().notification(title or addon_id, xbmc.getInfoLabel("$LOCALIZE[32715]"), xbmcgui.NOTIFICATION_INFO, 3000)
        return
    xbmcgui.Dialog().textviewer(title + " - Changelog", text)


LETTER_VIEWS = {
    "movies": (50, 51, 52, 53, 54, 55, 56, 57),
    "tv": (50, 51, 52, 53, 54, 55, 56, 57),
    "music": (50, 51, 52, 53, 54, 55),
    "fav": (50, 51),
    "other": (50, 51),
}
LETTER_TV = ("Container.Content(tvshows) | Container.Content(seasons) | Container.Content(episodes) | "
             "String.StartsWith(Container.FolderPath,videodb://tvshows) | "
             "String.StartsWith(Container.FolderPath,videodb://recentlyaddedepisodes)")


def _letter_area():
    cond = xbmc.getCondVisibility
    if cond("Window.IsActive(videos)"):
        return "tv" if cond(LETTER_TV) else "movies"
    if cond("Window.IsActive(music)"):
        return "music"
    if cond("Window.IsActive(favouritesbrowser)"):
        return "fav"
    return "other"


def _letters_set(area, view, off):
    """Set the letter overlay of one view on/off. When the last view of an area is switched off the area itself
    is switched off (and the single view choices go back to the default), so the main option is off, too."""
    cond = xbmc.getCondVisibility
    views = LETTER_VIEWS[area]
    area_key = "letter.off.%s" % area
    view_key = "%s.%d" % (area_key, view)
    if off:
        if all(v == view or cond("Skin.HasSetting(%s.%d)" % (area_key, v)) for v in views):
            xbmc.executebuiltin("Skin.SetBool(%s)" % area_key)
            for v in views:
                xbmc.executebuiltin("Skin.Reset(%s.%d)" % (area_key, v))
            return
        xbmc.executebuiltin("Skin.SetBool(%s)" % view_key)
    else:
        xbmc.executebuiltin("Skin.Reset(%s)" % view_key)


def toggle_letters():
    """Button in the library header: switch the big letter overlay for the list view that is shown now."""
    cond = xbmc.getCondVisibility
    area = _letter_area()
    views = LETTER_VIEWS[area]
    view = next((v for v in views if cond("Control.IsVisible(%d)" % v)), None)
    if view is None:
        return
    area_key = "letter.off.%s" % area
    view_key = "%s.%d" % (area_key, view)
    if cond("Skin.HasSetting(%s)" % area_key):
        # area is off: switch it on, but only for the view that is shown now
        xbmc.executebuiltin("Skin.Reset(%s)" % area_key)
        for other in views:
            if other != view:
                xbmc.executebuiltin("Skin.SetBool(%s.%d)" % (area_key, other))
        xbmc.executebuiltin("Skin.Reset(%s)" % view_key)
    else:
        _letters_set(area, view, not cond("Skin.HasSetting(%s)" % view_key))


def toggle_letters_option(area, view):
    """Single view options in the Lumen configuration."""
    if area not in LETTER_VIEWS:
        return
    view = int(view)
    key = "letter.off.%s.%d" % (area, view)
    _letters_set(area, view, not xbmc.getCondVisibility("Skin.HasSetting(%s)" % key))

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "letters":
        toggle_letters()
    elif len(sys.argv) > 3 and sys.argv[1] == "letters_opt":
        toggle_letters_option(sys.argv[2], sys.argv[3])
    elif len(sys.argv) > 2 and sys.argv[1] == "changelog":
        show_changelog(sys.argv[2])
    elif len(sys.argv) > 1 and sys.argv[1] == "favwatch":
        favourite_watch()
    elif len(sys.argv) > 1 and sys.argv[1] in ("reset", "reset_art", "reset_menu", "remove_widget", "apply_views", "reset_ok"):
        import lumenconfirm
        lumenconfirm.ACTIONS[sys.argv[1]]()
    elif len(sys.argv) > 2 and sys.argv[1] == "seasonfocus":
        import lumenseasons
        lumenseasons.focus(sys.argv[2])
    elif len(sys.argv) > 1 and sys.argv[1] == "episodefocus":
        import lumenseasons
        lumenseasons.focus_episode()
    elif len(sys.argv) > 1 and sys.argv[1] == "stopvideo":
        import lumenstopvideo
        lumenstopvideo.stop_video()
    elif len(sys.argv) > 1 and sys.argv[1] == "okmode":
        import lumenokmode
        lumenokmode.apply()
    elif len(sys.argv) > 1 and sys.argv[1] == "playercast":
        import lumenplayercast
        lumenplayercast.player_cast()
    elif len(sys.argv) > 1 and sys.argv[1] in ("upnext_play", "upnext_stop", "upnext_more", "upnext_preview", "upnext_preview_still"):
        import lumen
        lumen.handle(sys.argv[1][len("upnext_"):])
    elif len(sys.argv) > 1 and sys.argv[1] in ("export", "import"):
        import lumenbackup
        if sys.argv[1] == "export":
            lumenbackup.export_settings()
        else:
            lumenbackup.import_settings()
    else:
        set_properties()
