"""Confirmation dialogs and feedback popups for Lumen configuration actions."""
import re

import xbmc
import xbmcgui

import lumenresetdata as data
import lumenokmode
import lumenviews

HEADING_ID = 32738
LOCALIZE = re.compile(r"\$LOCALIZE\[(\d+)\]")
SETSTRING = re.compile(r"^Skin\.SetString\(([^,]+),(.*)\)$", re.S)


def tr(string_id):
    return xbmc.getInfoLabel("$LOCALIZE[%d]" % string_id)


def run(builtin):
    match = SETSTRING.match(builtin)
    if match:
        value = LOCALIZE.sub(lambda m: tr(int(m.group(1))), match.group(2))
        builtin = 'Skin.SetString(%s,"%s")' % (match.group(1), value.replace('"', '\\"'))
    xbmc.executebuiltin(builtin, True)


def confirm(question_id):
    return xbmcgui.Dialog().yesno(tr(HEADING_ID), tr(question_id))


def done(message_id):
    xbmcgui.Dialog().notification("Lumen", tr(message_id), xbmcgui.NOTIFICATION_INFO, 4000)


def reset_all():
    if not confirm(32730):
        return
    lumenokmode.restore()
    for builtin in data.RESET_ALL:
        run(builtin)
    lumenviews.apply_all()
    xbmc.executebuiltin("ReplaceWindow(skinsettings)")
    done(32731)


def reset_art():
    if not confirm(32732):
        return
    for builtin in data.RESET_ART:
        run(builtin)
    done(32733)


def reset_menu():
    if not confirm(32734):
        return
    for builtin in data.RESET_MENU:
        run(builtin)
    done(32735)


def remove_widget():
    slot = xbmc.getInfoLabel("Skin.String(setup.slot)")
    if not slot.isdigit() or not confirm(32736):
        return
    run("Skin.SetString(w%s.path,-)" % slot)
    run("Skin.SetString(w%s.title,-)" % slot)
    run("Skin.SetString(w%s.hide,0)" % slot)
    run("Skin.SetString(w%s.art,auto)" % slot)
    xbmc.executebuiltin("Action(PreviousMenu)")
    done(32737)


def apply_views():
    if not confirm(32852):
        return
    if lumenviews.apply_all() < 0:
        return
    done(32853)


def reset_ok():
    if not confirm(32877):
        return
    lumenokmode.restore()
    for name in ("click.home.movie", "click.home.series", "click.lib"):
        run("Skin.Reset(%s)" % name)
    done(32878)


ACTIONS = {
    "reset": reset_all,
    "reset_art": reset_art,
    "reset_menu": reset_menu,
    "remove_widget": remove_widget,
    "apply_views": apply_views,
    "reset_ok": reset_ok,
}