"""Cast portraits for the player info window (window 1107)."""
import json

import xbmc
import xbmcgui

MAX_CAST = 6


def player_cast():
    home = xbmcgui.Window(10000)
    for i in range(12):
        for key in ("name", "role", "thumb"):
            home.clearProperty("pcast.%d.%s" % (i, key))
    query = {"jsonrpc": "2.0", "id": 1, "method": "Player.GetItem",
             "params": {"playerid": 1, "properties": ["cast"]}}
    try:
        item = json.loads(xbmc.executeJSONRPC(json.dumps(query))).get("result", {}).get("item", {})
    except Exception:
        item = {}
    cast = [c for c in item.get("cast", []) if c.get("name")]
    for i, actor in enumerate(cast[:MAX_CAST]):
        home.setProperty("pcast.%d.name" % i, actor.get("name", ""))
        home.setProperty("pcast.%d.role" % i, actor.get("role", ""))
        home.setProperty("pcast.%d.thumb" % i, actor.get("thumbnail", ""))
    xbmc.executebuiltin("ActivateWindow(1107)")