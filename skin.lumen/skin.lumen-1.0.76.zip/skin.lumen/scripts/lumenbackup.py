"""Export / import of the Lumen skin settings as an XML file."""
import datetime
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape, quoteattr

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("skin.lumen")
SETTINGS_FILE = "special://profile/addon_data/skin.lumen/settings.xml"
ROOT_TAG = "lumen-settings"
# internal helper values of the configuration window: never saved or restored
SKIP_PREFIXES = ("setup.",)
SKIP_IDS = ("x",)


def tr(string_id):
    return xbmc.getInfoLabel("$LOCALIZE[%d]" % string_id)


def skipped(setting_id):
    return setting_id in SKIP_IDS or setting_id.startswith(SKIP_PREFIXES)


def read_file(path):
    f = xbmcvfs.File(path)
    try:
        return f.readBytes()
    finally:
        f.close()


def current_settings():
    """Return {id: (type, value)} as currently stored by Kodi for the skin."""
    result = {}
    path = SETTINGS_FILE
    if not xbmcvfs.exists(path):
        return result
    root = ET.fromstring(bytes(read_file(path)))
    for node in root.iter("setting"):
        setting_id = node.get("id")
        if not setting_id or skipped(setting_id):
            continue
        result[setting_id] = (node.get("type", "string"), node.text or "")
    return result


def pick_location(folder, heading):
    """Let the user pick a folder/file: Kodi sources, any drive/network share, or a typed path."""
    choice = xbmcgui.Dialog().select(tr(32723), [tr(32720), tr(32721), tr(32722)])
    if choice < 0:
        return ""
    mask = "" if folder else ".xml"
    if choice == 0:
        return xbmcgui.Dialog().browseSingle(3 if folder else 1, heading, "files", mask)
    if choice == 1:
        return xbmcgui.Dialog().browseSingle(3 if folder else 1, heading, "", mask)
    path = xbmcgui.Dialog().input(tr(32724) if folder else tr(32725), type=xbmcgui.INPUT_ALPHANUM)
    path = path.strip()
    if path and folder and not xbmcvfs.exists(path.rstrip("/\\") + "/"):
        xbmcgui.Dialog().ok(tr(32708), tr(32726))
        return ""
    return path

def export_settings():
    folder = pick_location(True, tr(32700))
    if not folder:
        return
    default_name = "lumen_einstellungen_%s.xml" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    name = xbmcgui.Dialog().input(tr(32701), defaultt=default_name)
    if not name:
        return
    if not name.lower().endswith(".xml"):
        name += ".xml"

    created = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<%s skin="skin.lumen" version=%s created=%s>' % (
                 ROOT_TAG, quoteattr(ADDON.getAddonInfo("version")), quoteattr(created))]
    for setting_id, (stype, value) in sorted(current_settings().items()):
        lines.append("    <setting id=%s type=%s>%s</setting>" % (quoteattr(setting_id), quoteattr(stype), escape(value)))
    lines.append("</%s>" % ROOT_TAG)
    data = ("\n".join(lines) + "\n").encode("utf-8")
    target = folder.rstrip("/\\") + "/" + name
    f = xbmcvfs.File(target, "w")
    try:
        ok = f.write(bytearray(data))
    finally:
        f.close()
    if ok:
        xbmcgui.Dialog().ok(tr(32708), tr(32702) + "\n" + target)
    else:
        xbmcgui.Dialog().ok(tr(32708), tr(32703))


def quote(value):
    return '"' + value.replace('"', '\\"') + '"'


def import_settings():
    path = pick_location(False, tr(32704))
    if not path or not path.lower().endswith(".xml"):
        return
    try:
        root = ET.fromstring(bytes(read_file(path)))
        if root.tag != ROOT_TAG or root.get("skin") != "skin.lumen":
            raise ValueError("not a lumen backup")
        backup = {}
        for node in root.iter("setting"):
            setting_id = node.get("id")
            if setting_id and not skipped(setting_id):
                backup[setting_id] = (node.get("type", "string"), node.text or "")
    except (ET.ParseError, ValueError):
        xbmcgui.Dialog().ok(tr(32708), tr(32705))
        return

    created = root.get("created", "?")
    if not xbmcgui.Dialog().yesno(tr(32708), tr(32706) % created):
        return

    # everything that is not part of the backup goes back to its default first
    for setting_id in current_settings():
        if setting_id not in backup:
            xbmc.executebuiltin("Skin.Reset(%s)" % setting_id, True)
    for setting_id, (stype, value) in backup.items():
        if stype == "bool":
            if value.strip().lower() == "true":
                xbmc.executebuiltin("Skin.SetBool(%s)" % setting_id, True)
            else:
                xbmc.executebuiltin("Skin.Reset(%s)" % setting_id, True)
        elif value:
            xbmc.executebuiltin("Skin.SetString(%s,%s)" % (setting_id, quote(value)), True)
        else:
            xbmc.executebuiltin("Skin.Reset(%s)" % setting_id, True)
    xbmc.executebuiltin("Skin.SetBool(lumen.init)", True)
    xbmcgui.Dialog().notification(tr(32708), tr(32707), xbmcgui.NOTIFICATION_INFO, 4000)
