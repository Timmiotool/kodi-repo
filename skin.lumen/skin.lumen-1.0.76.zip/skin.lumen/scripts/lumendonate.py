"""Opens the Lumen donation page (Ko-fi) in the system browser; falls back to a hint with the link."""
import xbmc
import xbmcgui

URL = "https://ko-fi.com/timmiotool"


def main():
    opened = False
    try:
        if xbmc.getCondVisibility("System.Platform.Android"):
            xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","","%s")' % URL)
            opened = True
        else:
            import webbrowser
            opened = bool(webbrowser.open(URL))
    except Exception:
        opened = False
    if not opened:
        xbmcgui.Dialog().notification("Lumen", xbmc.getInfoLabel("$LOCALIZE[32836]"), xbmcgui.NOTIFICATION_INFO, 6000)


main()