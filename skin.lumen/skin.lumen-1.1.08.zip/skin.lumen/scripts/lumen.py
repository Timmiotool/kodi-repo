"""Lumen background service (started at login).

Up Next ("Play next episode" popup, designs, test function), focus return after playback (home rows and library views),
seek target and progress ring of the player, default views for new lists and the artist slideshow setup.

Runs as a background service (xbmc.service extension of the skin). Options are Lumen skin settings
(Skin.HasSetting / Skin.String) so they can be changed in the Lumen configuration.
"""
import json
import math
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import lumenviews

HOME = 10000
DIALOG_ID = 1109
PLAYER_WINDOWS = (12005, 12006, 12600, 10100, 10101, 10107, 10120, 10130, 10142)  # full screen video/music/visualisation and OSD windows
SKIN_ID = "skin.lumen"
PREFIX = "lumen.upnext."

DEFAULT_TIME = 30       # show the popup this many seconds before the end
DEFAULT_COUNTDOWN = 15  # seconds between popup and automatic start
DEFAULT_STILL = 3       # ask "still watching?" after this many automatic episodes
STILL_WAIT = 30         # seconds to wait for an answer to "still watching?"


def tr(string_id):
    return xbmc.getInfoLabel("$LOCALIZE[%d]" % string_id)


def jsonrpc(method, params=None):
    query = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        query["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(query))).get("result", {}) or {}
    except Exception:
        return {}


def skin_bool(name):
    return xbmc.getCondVisibility("Skin.HasSetting(%s)" % name)


def skin_int(name, default):
    value = xbmc.getInfoLabel("Skin.String(%s)" % name).strip()
    try:
        return int(value)
    except ValueError:
        return default


def set_prop(name, value):
    xbmcgui.Window(HOME).setProperty(PREFIX + name, str(value))


def get_prop(name):
    return xbmcgui.Window(HOME).getProperty(PREFIX + name)


def clear_props():
    for name in ("title", "sub", "show", "thumb", "count", "mode", "progress", "action", "secs", "plot", "se", "etitle"):
        xbmcgui.Window(HOME).clearProperty(PREFIX + name)


LANG_CODES = (
    ("ger", "deu", "de", "german"),
    ("eng", "en", "english"),
    ("fre", "fra", "fr", "french"),
    ("spa", "es", "spanish"),
    ("ita", "it", "italian"),
    ("por", "pt", "portuguese"),
    ("dut", "nld", "nl", "dutch"),
    ("pol", "pl", "polish"),
    ("tur", "tr", "turkish"),
    ("rus", "ru", "russian"),
    ("cze", "ces", "cs", "czech"),
    ("slo", "slk", "sk", "slovak"),
    ("swe", "sv", "swedish"),
    ("dan", "da", "danish"),
    ("fin", "fi", "finnish"),
    ("nor", "nob", "nno", "no", "nb", "norwegian"),
    ("hun", "hu", "hungarian"),
    ("rum", "ron", "ro", "romanian"),
    ("gre", "ell", "el", "greek"),
    ("ukr", "uk", "ukrainian"),
    ("bul", "bg", "bulgarian"),
    ("hrv", "scr", "hr", "croatian"),
    ("jpn", "ja", "japanese"),
    ("chi", "zho", "zh", "chinese"),
    ("kor", "ko", "korean"),
    ("ara", "ar", "arabic"),
    ("heb", "he", "hebrew"),
    ("hin", "hi", "hindi"),
    ("tha", "th", "thai"),
    ("vie", "vi", "vietnamese"),
    ("ind", "id", "indonesian"),
    ("srp", "scc", "sr", "serbian"),
    ("slv", "sl", "slovenian"),
    ("lit", "lt", "lithuanian"),
    ("lav", "lv", "latvian"),
    ("est", "et", "estonian"),
    ("cat", "ca", "catalan"),
)

def lang_name(code):
    """Language code of a stream (ger, deu, de, german, ...) as name in the skin language (strings 31600...)."""
    c = (code or "").strip().lower()
    if not c:
        return ""
    for i, names in enumerate(LANG_CODES):
        if c in names:
            return xbmc.getLocalizedString(31600 + i)
    return code


_LANG_CACHE = {}
_LANG_LAST = [None]


def langs_for(dbtype, dbid):
    """All audio and subtitle language names of a library item (cached); the list item only knows the first stream."""
    key = (dbtype, dbid)
    if key in _LANG_CACHE:
        return _LANG_CACHE[key]
    methods = {"movie": ("VideoLibrary.GetMovieDetails", "movieid", "moviedetails"),
               "episode": ("VideoLibrary.GetEpisodeDetails", "episodeid", "episodedetails")}
    result = ("", "")
    if dbid and dbtype in methods:
        method, idkey, out = methods[dbtype]
        details = (jsonrpc(method, {idkey: int(dbid), "properties": ["streamdetails"]}).get(out, {}) or {}).get("streamdetails", {}) or {}
        texts = []
        for streams in (details.get("audio", []), details.get("subtitle", [])):
            names = []
            for s in streams:
                n = lang_name(s.get("language", ""))
                if n and n not in names:
                    names.append(n)
            texts.append(", ".join(names[:3]) + (" +%d" % (len(names) - 3) if len(names) > 3 else ""))
        result = (texts[0], texts[1])
    if len(_LANG_CACHE) > 400:
        _LANG_CACHE.clear()
    _LANG_CACHE[key] = result
    return result


def set_langs(dbtype, dbid):
    audio, sub = langs_for(dbtype, dbid)
    win = xbmcgui.Window(HOME)
    for prop, value in (("lumen.audlangs", audio), ("lumen.sublangs", sub)):
        if value:
            win.setProperty(prop, value)
        else:
            win.clearProperty(prop)


INFO_ROW_WIDTH = 1150
INFO_CHIP_KINDS = ("alang", "slang", "rating", "mpaa", "premiered", "added", "playcount", "lastplayed", "director", "studio")


def info_chip_text(kind, audio, sub):
    li = xbmc.getInfoLabel
    if kind == "rating": return li("ListItem.Rating")
    if kind == "mpaa": return li("ListItem.MPAA")
    if kind == "premiered": return li("ListItem.Premiered")
    if kind == "added": return li("ListItem.DateAdded")
    if kind == "playcount": return (li("ListItem.PlayCount") + "x") if li("ListItem.PlayCount") else ""
    if kind == "lastplayed": return li("ListItem.LastPlayed")
    if kind == "director": return ("%s: %s" % (xbmc.getLocalizedString(31026), li("ListItem.Director"))) if li("ListItem.Director") else ""
    if kind == "studio": return li("ListItem.Studio")
    if kind == "alang": return audio or ""
    if kind == "slang": return sub or ""
    return ""


def info_chip_rows(audio, sub):
    """Info page: chips fill the first row; those that no longer fit move to the second row (property lumen.irow.<kind>)."""
    win = xbmcgui.Window(HOME)
    used = 0
    full = False
    rows = 0
    for kind in INFO_CHIP_KINDS:
        win.clearProperty("lumen.irow." + kind)
        if xbmc.getCondVisibility("Skin.HasSetting(chip.info.%s)" % kind):
            continue
        text = info_chip_text(kind, audio, sub)
        if not text:
            continue
        width = 56 + 10 * len(text) + (10 if used else 0)
        if full or used + width > INFO_ROW_WIDTH:
            full = True
            win.setProperty("lumen.irow." + kind, "2")
            rows = 2
        else:
            used += width
            rows = max(rows, 1)
    win.setProperty("lumen.irow.n", str(rows))      # 0, 1 or 2: the rows below the plot only take space when they are used

def stream_langs():
    """Info page: languages of the shown item right away (also kept up to date by update_langs)."""
    dbid = xbmc.getInfoLabel("ListItem.DBID")
    dbtype = xbmc.getInfoLabel("ListItem.DBType")
    _LANG_LAST[0] = (dbtype, dbid)
    set_langs(dbtype, dbid)
    info_chip_rows(*langs_for(dbtype, dbid))


_SPOT_LAST = [None]


def update_spot_langs():
    """Home screen detail area (spotlight): its item is not focused, so it gets its own properties."""
    dbid = xbmc.getInfoLabel("Container(9199).ListItem.DBID")
    dbtype = xbmc.getInfoLabel("Container(9199).ListItem.DBType")
    key = (dbtype, dbid)
    if key == _SPOT_LAST[0]:
        return
    _SPOT_LAST[0] = key
    audio, sub = langs_for(dbtype, dbid)
    win = xbmcgui.Window(HOME)
    for prop, value in (("lumen.spotaud", audio), ("lumen.spotsub", sub)):
        if value:
            win.setProperty(prop, value)
        else:
            win.clearProperty(prop)

VIEW_CHIPS = (
    ("dur", "$INFO[ListItem.Duration(hh:mm:ss)]"),
    ("vcodec", "$VAR[FlagVCodec]"),
    ("res", "$VAR[FlagRes]"),
    ("aspect", "$INFO[ListItem.VideoAspect]:1"),
    ("acodec", "$VAR[FlagACodec]"),
    ("ach", "$VAR[FlagCh]"),
    ("alang", None),
    ("slang", None),
    ("rating", "$INFO[ListItem.Rating]"),
    ("mpaa", "$INFO[ListItem.MPAA]"),
    ("premiered", "$INFO[ListItem.Premiered]"),
    ("added", "$INFO[ListItem.DateAdded]"),
    ("playcount", "$INFO[ListItem.PlayCount]"),
    ("lastplayed", "$INFO[ListItem.LastPlayed]"),
    ("director", "$INFO[ListItem.Director]"),
    ("studio", "$INFO[ListItem.Studio]"),
)
VIEW_ROW_WIDTH = 396
VIEW_LOW_WIDTH = 690     # rows 6 and 7 sit below the poster and are wider
VIEW_ROWS = 7


def view_rows(audio, sub):
    """Info view: chips fill row 1, then row 2 ... (property lumen.vrow.<kind> = row number)."""
    win = xbmcgui.Window(HOME)
    row, used = 1, 0
    rows_used = 0
    for kind, expr in VIEW_CHIPS:
        win.clearProperty("lumen.vrow." + kind)
        if xbmc.getCondVisibility("Skin.HasSetting(chip.view.%s)" % kind):
            continue
        text = audio if kind == "alang" else sub if kind == "slang" else xbmc.getInfoLabel(expr)
        if not text:
            continue
        if kind == "playcount":
            text += "x"
        elif kind == "director":
            text = "%s: %s" % (xbmc.getLocalizedString(31026), text)
        width = min(520, 56 + 10 * len(text))
        if used and used + 8 + width > (VIEW_ROW_WIDTH if row < 5 else VIEW_LOW_WIDTH if row > 5 else VIEW_ROW_WIDTH):
            row += 1
            used = 0
        if row > VIEW_ROWS:
            row = VIEW_ROWS
        used += width + (8 if used else 0)
        win.setProperty("lumen.vrow." + kind, str(row))
        rows_used = row
    win.setProperty("lumen.vrow.n", str(rows_used))


# Chips below the title (views, widgets, home detail area): flowing rows. Each set = (area, id, row width, bottom-up numbering)
RW_KINDS = ("dur", "vcodec", "res", "aspect", "acodec", "ach", "alang", "slang", "rating", "mpaa", "premiered",
            "added", "playcount", "lastplayed", "director", "studio")
RW_SETS = (("view", "a", 1720, True), ("view", "b", 1175, True), ("view", "c", 1320, False),
           ("view", "tvp", [380] * 5 + [660] * 2, False), ("view", "tvl", [660] * 4, False))
RW_SET_HOME = (("home", "a", 1720, False),)
RW_MAXROWS = 3
_RW_LAST = [None]
_RW_HOME_LAST = [None]
_RW_WIDGET_LAST = [None]


def rw_texts(ip, vp, audio, sub):
    li = xbmc.getInfoLabel
    out = {}
    dbtype = li(ip + ".DBType")
    if li(ip + ".Duration") and dbtype not in ("tvshow", "season"):
        out["dur"] = li(ip + ".Duration(hh:mm:ss)")
    if li(ip + ".VideoCodec"): out["vcodec"] = li("$VAR[%sFlagVCodec]" % vp)
    if li(ip + ".VideoResolution"): out["res"] = li("$VAR[%sFlagRes]" % vp)
    if li(ip + ".VideoAspect"): out["aspect"] = li(ip + ".VideoAspect") + ":1"
    if li(ip + ".AudioCodec"): out["acodec"] = li("$VAR[%sFlagACodec]" % vp)
    if li(ip + ".AudioChannels"): out["ach"] = li("$VAR[%sFlagCh]" % vp)
    if audio: out["alang"] = audio
    if sub: out["slang"] = sub
    for kind, label in (("rating", "Rating"), ("mpaa", "MPAA"), ("premiered", "Premiered"), ("added", "DateAdded"),
                        ("lastplayed", "LastPlayed"), ("studio", "Studio")):
        if li(ip + "." + label): out[kind] = li(ip + "." + label)
    if li(ip + ".PlayCount"): out["playcount"] = li(ip + ".PlayCount") + "x"
    if li(ip + ".Director"): out["director"] = "%s: %s" % (xbmc.getLocalizedString(31026), li(ip + ".Director"))
    return out


def rw_rows(sets, ip, vp, audio, sub):
    """Splits the chips into rows (properties lumen.rw.<area>.<id>.<kind> = row, .n = number of rows). Order of the
    chips like in the skin; widths are estimated; bottom-up sets count the rows from the bottom row upwards."""
    win = xbmcgui.Window(HOME)
    texts = rw_texts(ip, vp, audio, sub)
    for area, sid, width_max, up in sets:
        prefix = "lumen.rw.%s.%s." % (area, sid)
        widths = width_max if isinstance(width_max, list) else [width_max] * RW_MAXROWS
        rows, used, row = {}, (66 if sid in ("c", "tvp", "tvl") else 0), 1
        for kind in RW_KINDS:
            win.clearProperty(prefix + kind)
            if kind not in texts or xbmc.getCondVisibility("Skin.HasSetting(chip.%s.%s)" % (area, kind)):
                continue
            width = min(520, 56 + 10 * len(texts[kind]))
            if used and used + 10 + width > widths[row - 1]:
                row = min(row + 1, len(widths))
                used = 0
            while width > widths[row - 1] and row < len(widths) and widths[row] > widths[row - 1]:
                row += 1      # long chip: jump to the first wider row
                used = 0
            used += width + (10 if used else 0)
            rows[kind] = row
        count = max(rows.values()) if rows else 1
        for kind, r in rows.items():
            win.setProperty(prefix + kind, str(count - r + 1 if up else r))
        win.setProperty(prefix + "n", str(count))


def update_rw():
    li = xbmc.getInfoLabel
    key = (xbmcgui.getCurrentWindowId(), li("ListItem.DBType"), li("ListItem.DBID"), li("ListItem.Label"), li("ListItem.FolderPath"))
    if not li("ListItem.Label"):
        return
    if key == _RW_LAST[0]:
        return
    _RW_LAST[0] = key
    audio, sub = langs_for(li("ListItem.DBType"), li("ListItem.DBID"))
    rw_rows(RW_SETS, "ListItem", "", audio, sub)


def update_rw_home():
    li = xbmc.getInfoLabel
    key = (li("Container(9199).ListItem.DBType"), li("Container(9199).ListItem.DBID"), li("Container(9199).ListItem.Label"))
    if key == _RW_HOME_LAST[0]:
        return
    _RW_HOME_LAST[0] = key
    audio, sub = langs_for(key[0], key[1])
    rw_rows(RW_SET_HOME, "Container(9199).ListItem", "S", audio, sub)


def update_rw_widget():
    """Home widgets: the detail area shows the last focused widget item (HomeLast = container id)."""
    li = xbmc.getInfoLabel
    cid = li("Window(home).Property(HomeLast)")
    if not cid:
        return
    ip = "Container(%s).ListItem" % cid
    key = (cid, li(ip + ".DBType"), li(ip + ".DBID"), li(ip + ".Label"))
    if key == _RW_WIDGET_LAST[0]:
        return
    _RW_WIDGET_LAST[0] = key
    audio, sub = langs_for(key[1], key[2])
    rw_rows((("widget", "a", 1720, False),), ip, "H" + cid, audio, sub)


_VIEW_LAST = [None]

def update_langs():
    """Follows the focused list item (views, widgets, info page): sets the language properties used by the language chips."""
    dbid = xbmc.getInfoLabel("ListItem.DBID")
    dbtype = xbmc.getInfoLabel("ListItem.DBType")
    key = (dbtype, dbid)
    shown = xbmc.getCondVisibility("Control.IsVisible(52)")
    vkey = (dbtype, dbid, xbmcgui.getCurrentWindowId(), xbmc.getInfoLabel("Container.NumItems") if shown else None)
    if not shown:
        _VIEW_LAST[0] = None
    if key == _LANG_LAST[0]:
        if shown and _VIEW_LAST[0] != vkey:
            _VIEW_LAST[0] = vkey
            view_rows(*langs_for(dbtype, dbid))
        return
    _LANG_LAST[0] = key
    set_langs(dbtype, dbid)
    if shown:
        _VIEW_LAST[0] = vkey
        view_rows(*langs_for(dbtype, dbid))

PINFO_ROW_WIDTH = 1040
P4_ROW_WIDTH = 1090
PINFO_CHIPS = (
    ("dur", "$INFO[VideoPlayer.Duration]"),
    ("vcodec", "$VAR[PFlagVCodec]"),
    ("res", "$VAR[PFlagRes]"),
    ("aspect", "$INFO[VideoPlayer.VideoAspect]:1"),
    ("acodec", "$VAR[PFlagACodec]"),
    ("ach", "$VAR[PFlagCh]"),
    ("alang", "$VAR[LangAudioVP]"),
    ("slang", "$VAR[LangSubVP]"),
    ("rating", "$INFO[VideoPlayer.Rating]"),
    ("mpaa", "$INFO[VideoPlayer.MPAA]"),
    ("premiered", "$INFO[VideoPlayer.Premiered]"),
    ("playcount", "$INFO[VideoPlayer.PlayCount]"),
    ("lastplayed", "$INFO[VideoPlayer.LastPlayed]"),
    ("director", "$INFO[VideoPlayer.Director]"),
    ("studio", "$INFO[VideoPlayer.Studio]"),
)


def pinfo_rows():
    """Player info page (3 rows, lumen.prow.<kind>) and player 4 chips (3 rows, lumen.p4row.<kind>)."""
    win = xbmcgui.Window(HOME)
    # language chips of the playing library item: all audio / subtitle languages (not only the active stream)
    dbid = xbmc.getInfoLabel("VideoPlayer.DBID")
    dbtype = "episode" if xbmc.getCondVisibility("VideoPlayer.Content(episodes)") else "movie" if xbmc.getCondVisibility("VideoPlayer.Content(movies)") else ""
    audio, sub = langs_for(dbtype, dbid) if dbtype and dbid and dbid != "0" else ("", "")
    for prop, value in (("lumen.playeraud", audio), ("lumen.playersub", sub)):
        if value:
            win.setProperty(prop, value)
        else:
            win.clearProperty(prop)
    texts = {}
    for kind, expr in PINFO_CHIPS:
        text = xbmc.getInfoLabel(expr)
        if not text:
            continue
        if kind == "director":
            text = "%s: %s" % (xbmc.getLocalizedString(31026), text)
        elif kind == "playcount":
            text += "x"
        texts[kind] = text
    for prefix, area, width_max, max_rows in (("lumen.prow.", "pinfo", PINFO_ROW_WIDTH, 3), ("lumen.p4row.", "player", P4_ROW_WIDTH, 3)):
        row, used, count = 1, 0, 1
        any_chip = False
        for kind, expr in PINFO_CHIPS:
            win.clearProperty(prefix + kind)
            if kind not in texts or xbmc.getCondVisibility("Skin.HasSetting(chip.%s.%s)" % (area, kind)):
                continue
            width = min(520, 56 + 10 * len(texts[kind]))
            if used and used + 10 + width > width_max:
                row = min(row + 1, max_rows)
                used = 0
            used += width + (10 if used else 0)
            count = row
            any_chip = True
            if row > 1:
                win.setProperty(prefix + kind, str(row))
        win.setProperty(prefix + "n", str(count if any_chip else 0))
def handle(action):
    """Called from the dialog buttons (RunScript(skin.lumen,upnext_<action>)) and the preview buttons in the settings."""
    if action in ("preview", "preview_still"):
        preview(action == "preview_still")
        return
    if action == "pinforows":
        pinfo_rows()
        return
    if action == "streamlangs":
        stream_langs()
        return
    if action in ("playertest_video", "playertest_music"):
        player_test(action == "playertest_music")
        return
    if get_prop("preview") == "1":
        if action in ("play", "stop"):
            set_prop("preview", "0")   # the preview loop closes the dialog
        return
    set_prop("action", action)


def preview(still):
    """Settings test function: shows the Up Next dialog with the chosen design and the data of a library episode."""
    if get_prop("preview") == "1":
        return
    episode = None
    result = jsonrpc("VideoLibrary.GetEpisodes", {
        "properties": ["season", "episode", "title", "showtitle", "art", "plot"],
        "sort": {"method": "lastplayed", "order": "descending"}, "limits": {"start": 0, "end": 1}})
    episodes = result.get("episodes") or []
    if episodes:
        episode = episodes[0]
    else:
        episode = {"season": 1, "episode": 5, "title": "Example", "showtitle": "Example series",
                   "plot": "Example description of the next episode.", "art": {}}
    art = episode.get("art", {})
    mode = "still" if still else "next"
    countdown = skin_int("upnext.count", DEFAULT_COUNTDOWN)
    auto = not skin_bool("upnext.noauto")
    set_prop("preview", "1")
    set_prop("thumb", art.get("thumb") or art.get("tvshow.fanart") or art.get("tvshow.poster", ""))
    set_prop("show", episode.get("showtitle", ""))
    set_prop("title", "S%02dE%02d  %s" % (episode.get("season", 0), episode.get("episode", 0), episode.get("title", "")))
    set_prop("se", "S%d:E%d" % (episode.get("season", 0), episode.get("episode", 0)))
    set_prop("etitle", episode.get("title", ""))
    set_prop("plot", episode.get("plot", ""))
    set_prop("mode", mode)
    set_prop("sub", tr(32764) if still else tr(32760))
    set_prop("action", "")
    set_prop("count", "")
    set_prop("progress", 0)
    set_prop("secs", "")
    xbmc.executebuiltin("ActivateWindow(%d)" % DIALOG_ID)
    monitor = xbmc.Monitor()
    t0 = time.time()
    limit = STILL_WAIT if still else (countdown if auto else 20)
    while get_prop("preview") == "1" and not monitor.abortRequested():
        waited = time.time() - t0
        if waited > 2 and not xbmc.getCondVisibility("Window.IsActive(%d)" % DIALOG_ID):
            break   # closed with Back
        if waited >= limit:
            break
        left = max(0, int(math.ceil(limit - waited)))
        if still:
            set_prop("count", tr(32766) % left)
            set_prop("progress", int(100 * (1 - waited / limit)))
        elif auto:
            set_prop("count", tr(32763) % left)
            set_prop("secs", left)
            set_prop("progress", int(100 * max(0.0, 1 - waited / max(1, limit))))
        monitor.waitForAbort(0.1)
    if xbmc.getCondVisibility("Window.IsActive(%d)" % DIALOG_ID):
        xbmc.executebuiltin("Dialog.Close(%d)" % DIALOG_ID)
    clear_props()
    xbmcgui.Window(HOME).clearProperty(PREFIX + "preview")


def player_test(music):
    """Settings test function: plays a random library item paused and shows the player OSD in the chosen design."""
    if music:
        result = jsonrpc("AudioLibrary.GetSongs", {"sort": {"method": "random"}, "limits": {"start": 0, "end": 1}})
        items = result.get("songs") or []
        key, window = "songid", "musicosd"
    else:
        result = jsonrpc("VideoLibrary.GetMovies", {"sort": {"method": "random"}, "limits": {"start": 0, "end": 1}})
        items = result.get("movies") or []
        key, window = "movieid", "videoosd"
        if not items:
            result = jsonrpc("VideoLibrary.GetEpisodes", {"sort": {"method": "random"}, "limits": {"start": 0, "end": 1}})
            items = result.get("episodes") or []
            key = "episodeid"
    if not items:
        xbmcgui.Dialog().notification("Lumen", tr(32698), xbmcgui.NOTIFICATION_INFO, 3000)
        return
    jsonrpc("Player.Open", {"item": {key: items[0][key]}, "options": {"resume": False}})
    monitor = xbmc.Monitor()
    t0 = time.time()
    while time.time() - t0 < 20 and not monitor.abortRequested():
        if xbmc.getCondVisibility("Player.HasMedia + Player.Playing + Player.TimeCached | Player.HasMedia + Player.Playing"):
            break
        monitor.waitForAbort(0.2)
    monitor.waitForAbort(1.5)
    if xbmc.getCondVisibility("Player.Playing"):
        xbmc.executebuiltin("PlayerControl(Play)")   # pause
    if music:
        xbmc.executebuiltin("ActivateWindow(visualisation)")
        monitor.waitForAbort(1.0)
    xbmc.executebuiltin("ActivateWindow(%s)" % window)


class UpNextPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.auto_started = False
        self.auto_count = 0
        self.home_item = None      # item of a home widget that was played from the home screen
        self.home_pending = None   # same item, waiting for the home screen to come back
        self.home_last = None      # last focused home widget item (updated while the home screen is shown)
        self.home_stamp = 0.0
        self.lib_last = None       # focused item of a library view (updated while the view is shown)
        self.lib_item = None       # item of a library view that was played from there
        self.lib_pending = None    # same item, waiting for the view to come back
        self.lib_stamp = 0.0
        self.lib_play = None       # (dbtype, dbid) of the item that played last

    def remember_home_item(self):
        """Called often: remember the focused item of the home widgets (the play start may happen behind a dialog)."""
        window = xbmcgui.getCurrentWindowId()
        if window == HOME:
            if xbmcgui.getCurrentWindowDialogId() != 9999:
                return  # a dialog (e.g. context menu) is open above the home screen: keep what we know
            cid = xbmcgui.Window(HOME).getProperty("HomeLast")
            on_row = cid.isdigit() and xbmc.getCondVisibility("Control.HasFocus(%s)" % cid)
            # the Play button above the rows plays the item that is highlighted in the last row
            on_button = cid.isdigit() and xbmc.getCondVisibility(
                "Control.HasFocus(9290) | Control.HasFocus(9291) | Control.HasFocus(9292) | Control.HasFocus(9293)")
            if on_row or on_button:
                prefix = "Container(%s).ListItem" % cid
                self.home_last = {"cid": int(cid),
                                  "dbid": xbmc.getInfoLabel(prefix + ".DBID"),
                                  "dbtype": xbmc.getInfoLabel(prefix + ".DBType"),
                                  "label": xbmc.getInfoLabel(prefix + ".Label")}
            else:
                self.home_last = None
        elif window not in (12005, 12006, 10107, 10100, 10101):
            self.home_last = None  # some other window: not started from home

    def remember_lib_item(self):
        """Remember the focused item of the library view (list/poster views 50-69) so that it can be focused again."""
        window = xbmcgui.getCurrentWindowId()
        if window == HOME or window in PLAYER_WINDOWS:
            if window == HOME:
                self.lib_last = None
            return
        if xbmcgui.getCurrentWindowDialogId() != 9999:
            return  # a dialog (context menu, resume question) is open above the view: keep what we know
        for cid in range(50, 70):
            if xbmc.getCondVisibility("Control.HasFocus(%d)" % cid):
                prefix = "Container(%d).ListItem" % cid
                current = xbmc.getInfoLabel("Container(%d).CurrentItem" % cid)
                if not current.isdigit() or int(current) < 1:
                    break
                self.lib_last = {"window": window, "cid": cid, "index": int(current) - 1,
                                 "dbid": xbmc.getInfoLabel(prefix + ".DBID"),
                                 "dbtype": xbmc.getInfoLabel(prefix + ".DBType"),
                                 "label": xbmc.getInfoLabel(prefix + ".Label")}
                return
        if self.lib_last and self.lib_last["window"] != window:
            self.lib_last = None
    def onPlayBackStarted(self):
        if xbmc.getSkinDir() != SKIN_ID:
            return
        if self.home_last:
            self.home_item = self.home_last
        elif self.home_item:
            pass  # the next episode replaced the running one (no stop in between): same origin
        elif self.home_pending and time.time() - self.home_stamp < 10:
            self.home_item = self.home_pending  # the next episode started by itself: same origin
        else:
            self.home_item = None
        self.home_last = None
        self.home_pending = None
        if self.lib_last:
            self.lib_item = self.lib_last
        elif self.lib_item:
            pass  # the next item replaced the running one: same origin
        elif self.lib_pending and time.time() - self.lib_stamp < 10:
            self.lib_item = self.lib_pending
        else:
            self.lib_item = None
        self.lib_last = None
        self.lib_pending = None
        self.lib_play = None

    def onPlayBackStopped(self):
        if self.home_item:
            self.home_pending = self.home_item
            self.home_stamp = time.time()
        self.home_item = None
        if self.lib_item:
            self.lib_pending = self.lib_item
            self.lib_stamp = time.time()
        self.lib_item = None

    def onPlayBackEnded(self):
        self.onPlayBackStopped()
    def onAVStarted(self):
        if self.lib_item:
            played = jsonrpc("Player.GetItem", {"playerid": 1 if self.isPlayingVideo() else 0}).get("item", {})
            if played.get("id", -1) >= 0:
                self.lib_play = (played.get("type", ""), str(played["id"]))
        if self.auto_started:
            self.auto_count += 1
        else:
            self.auto_count = 0
        self.auto_started = False

BAR_WIDTH = 1720        # width of the seek bar in the skin (pixels)
BAR_STEP = 17           # coarse step of the marker animation in the skin


def parse_time(text):
    """'1:02:03' / '02:03' -> seconds, None if it is not a time."""
    try:
        parts = [int(p) for p in text.strip().split(":")]
    except ValueError:
        return None
    seconds = 0
    for part in parts:
        seconds = seconds * 60 + part
    return seconds


def clear_seek_target():
    window = xbmcgui.Window(HOME)
    window.clearProperty(PREFIX + "seekc")
    window.clearProperty(PREFIX + "seekf")


def update_seek_target(player, enabled):
    """While the user is seeking (e.g. pressing a skip key several times) show the target position on the bar."""
    if not enabled or not player.isPlayingVideo():
        clear_seek_target()
        return
    if not xbmc.getCondVisibility("Player.Seeking | Player.HasPerformedSeek(2)"):
        clear_seek_target()
        return
    target = parse_time(xbmc.getInfoLabel("Player.SeekTime"))
    try:
        total = player.getTotalTime()
    except Exception:
        total = 0
    if target is None or total <= 0:
        clear_seek_target()
        return
    pixels = max(0, min(BAR_WIDTH, int(BAR_WIDTH * target / total)))
    set_prop("seekc", pixels // BAR_STEP)
    set_prop("seekf", pixels % BAR_STEP)

RING_FRAMES = 72
RING_SECONDS = 14.0


def update_ring():
    """Frame animation of the logo ring (a rotate animation would turn the circle into an ellipse on non 16:9 screens)."""
    if xbmc.getCondVisibility("Window.IsActive(1110) | Control.HasFocus(108) | Control.HasFocus(4010)"):
        frame = int((time.time() % RING_SECONDS) / RING_SECONDS * RING_FRAMES) % RING_FRAMES
        set_prop("ringtex", "special://skin/media/ring_%02d.png" % frame)

# Artist Slideshow settings of the Lumen reference installation (applied once after installation)
SLIDESHOW_SETTINGS = {
    "fanarttv": "true",
    "theaudiodb": "true",
    "ai_theaudiodb": "true",
    "ai_lastfm": "true",
    "language": "16",
    "ab_theaudiodb": "true",
    "ab_lastfm": "true",
    "sa_lastfm": "true",
}


def configure_artistslideshow():
    """Apply the reference settings to Artist Slideshow once, if it is installed and was not configured by Lumen before."""
    if xbmc.getCondVisibility("Skin.HasSetting(lumen.asinit)"):
        return
    if not xbmc.getCondVisibility("System.HasAddon(script.artistslideshow)"):
        return
    try:
        addon = xbmcaddon.Addon("script.artistslideshow")
        for key, value in SLIDESHOW_SETTINGS.items():
            addon.setSetting(key, value)
    except Exception:
        return
    xbmc.executebuiltin("Skin.SetBool(lumen.asinit)")

SLIDESHOW = {"started": False}


_fresh = {"seen": False}


def apply_views_after_first_init():
    """On a fresh installation the skin defaults are set when the first window loads (lumen.init false -> true).
    Right after that, switch all saved Lumen views to the default views."""
    if not skin_bool("lumen.init"):
        _fresh["seen"] = True
    elif _fresh["seen"]:
        _fresh["seen"] = False
        lumenviews.apply_all()

def apply_default_view():
    """Give new paths the Lumen standard view (see lumenviews.py)."""
    window = xbmcgui.getCurrentWindowId()
    if window in lumenviews.DEFAULT_VIEWS:
        lumenviews.apply(window)


def update_slideshow():
    """Start Artist Slideshow while music from the library plays, so the home screen has images before the player is opened."""
    if not xbmc.getCondVisibility("Player.HasAudio"):
        SLIDESHOW["started"] = False
        return
    if SLIDESHOW["started"]:
        return
    if xbmc.getCondVisibility("!Player.HasVideo + !String.IsEmpty(MusicPlayer.DBID) + !Skin.HasSetting(music.nofanart) + "
                              "!Skin.HasSetting(home.nonowplaying) + System.AddonIsEnabled(script.artistslideshow)"):
        SLIDESHOW["started"] = True
        xbmc.executebuiltin("RunScript(script.artistslideshow)")

def current_episode():
    """Info about the playing episode or None (only library episodes are handled)."""
    result = jsonrpc("Player.GetItem", {"playerid": 1, "properties": [
        "tvshowid", "season", "episode", "showtitle", "title", "playcount"]})
    item = result.get("item", {})
    if item.get("type") != "episode" or item.get("id", -1) < 0 or item.get("tvshowid", -1) < 0:
        return None
    return item


def find_next(item, allow_next_season):
    result = jsonrpc("VideoLibrary.GetEpisodes", {
        "tvshowid": item["tvshowid"],
        "properties": ["season", "episode", "title", "showtitle", "art", "playcount", "runtime", "plot"],
        "sort": {"method": "episode", "order": "ascending"}})
    here = (item.get("season", 0), item.get("episode", 0))
    best = None
    for ep in result.get("episodes", []):
        key = (ep.get("season", 0), ep.get("episode", 0))
        if key <= here:
            continue
        if ep.get("season", 0) == 0 and here[0] != 0:
            continue
        if not allow_next_season and key[0] != here[0]:
            continue
        if best is None or key < (best.get("season", 0), best.get("episode", 0)):
            best = ep
    return best


def home_item_focused(item):
    """True when the focus is on the played item of the home row."""
    cid = item["cid"]
    if not xbmc.getCondVisibility("Control.HasFocus(%d)" % cid):
        return False
    prefix = "Container(%d).ListItem" % cid
    if item["dbid"] and item["dbid"] != "0":
        return (xbmc.getInfoLabel(prefix + ".DBID") == item["dbid"]
                and xbmc.getInfoLabel(prefix + ".DBType") == item["dbtype"])
    return xbmc.getInfoLabel(prefix + ".Label") == item["label"]

def focus_home_item(item):
    """Put the focus back on the item of the home widget that was played (it may have moved in the list)."""
    cid = item["cid"]
    count = int(xbmc.getInfoLabel("Container(%d).NumItems" % cid) or 0)
    found = -1
    for index in range(count):
        prefix = "Container(%d).ListItemAbsolute(%d)" % (cid, index)
        if item["dbid"] and item["dbid"] != "0":
            if (xbmc.getInfoLabel(prefix + ".DBID") == item["dbid"]
                    and xbmc.getInfoLabel(prefix + ".DBType") == item["dbtype"]):
                found = index
                break
        elif xbmc.getInfoLabel(prefix + ".Label") == item["label"]:
            found = index
            break
    if found >= 0:
        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, found))
    return found >= 0

def focus_lib_item(item, play):
    """Focus the library view item that was played last and scroll the list to it."""
    cid = item["cid"]
    count = int(xbmc.getInfoLabel("Container(%d).NumItems" % cid) or 0)
    wanted = []
    if play:
        wanted.append(("dbid", play))
    if item["dbid"] and item["dbid"] != "0":
        wanted.append(("dbid", (item["dbtype"], item["dbid"])))
    found = -1
    for kind, (dbtype, dbid) in wanted:
        for index in range(count):
            prefix = "Container(%d).ListItemAbsolute(%d)" % (cid, index)
            if (xbmc.getInfoLabel(prefix + ".DBID") == dbid
                    and xbmc.getInfoLabel(prefix + ".DBType") == dbtype):
                found = index
                break
        if found >= 0:
            break
    if found < 0:
        for index in range(count):
            if xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Label" % (cid, index)) == item["label"]:
                found = index
                break
    if found < 0 and item["index"] < count:
        found = item["index"]
    if found >= 0:
        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, found))

NETWORK_SCHEMES = ("smb://", "nfs://", "ftp://", "sftp://", "webdav://", "dav://", "upnp://")
MEDIA_EXTENSIONS = (".mkv", ".mp4", ".avi", ".m4v", ".mov", ".ts", ".m2ts", ".wmv", ".mpg", ".mpeg", ".iso", ".mp3", ".flac")


def _wake_source(path, depth=0):
    """Read a few bytes of a media file below a network source: only a real file read makes the NAS spin up its disks."""
    try:
        dirs, files = xbmcvfs.listdir(path)
    except Exception:
        return False
    for name in files:
        if name.lower().endswith(MEDIA_EXTENSIONS):
            try:
                handle = xbmcvfs.File(path + name)
                try:
                    handle.readBytes(4096)
                finally:
                    handle.close()
                return True
            except Exception as error:
                xbmc.log("Lumen: NAS wake could not read %s: %s" % (path + name, error), xbmc.LOGINFO)
                return False
    if depth < 3:
        for name in dirs[:6]:
            if _wake_source(path + name + "/", depth + 1):
                return True
    return False


def wake_nas():
    """Skin option Wake up NAS disks at start: touches every network video/music source once (background thread)."""
    sources = []
    for media in ("video", "music"):
        result = jsonrpc("Files.GetSources", {"media": media})
        for source in result.get("sources", []):
            path = source.get("file", "")
            if path.lower().startswith(NETWORK_SCHEMES) and not path.startswith("multipath://"):
                sources.append(path if path.endswith("/") else path + "/")
    done = set()
    for path in sources:
        if path in done:
            continue
        done.add(path)
        started = time.time()
        woke = _wake_source(path)
        xbmc.log("Lumen: NAS wake %s -> %s (%.1f s)" % (path, "read ok" if woke else "no file read", time.time() - started), xbmc.LOGINFO)


def start_nas_wake():
    thread = threading.Thread(target=wake_nas, name="lumen-nas-wake")
    thread.daemon = True
    thread.start()


def run():
    monitor = xbmc.Monitor()
    player = UpNextPlayer()
    xbmcgui.Window(HOME).setProperty(PREFIX + "alive", "1")
    nas_woken = False
    state = {"key": None, "next": None, "shown": False, "dismissed": False, "t0": 0.0, "mode": None, "hold": False}

    def close_dialog():
        if xbmc.getCondVisibility("Window.IsActive(%d)" % DIALOG_ID):
            xbmc.executebuiltin("Dialog.Close(%d)" % DIALOG_ID)
        clear_props()
        state["shown"] = False

    def reset():
        if state["shown"]:
            close_dialog()
        state.update({"key": None, "next": None, "shown": False, "dismissed": False, "mode": None, "hold": False})

    def play_next(auto):
        episode = state["next"]
        item = state.get("item") or {}
        close_dialog()
        state["dismissed"] = True
        if not episode:
            return
        try:
            total = player.getTotalTime()
            if total > 0 and player.getTime() / total < 0.9 and item.get("id", -1) >= 0:
                jsonrpc("VideoLibrary.SetEpisodeDetails", {
                    "episodeid": item["id"], "playcount": item.get("playcount", 0) + 1,
                    "resume": {"position": 0, "total": 0}})
        except Exception:
            pass
        player.auto_started = auto
        state["cool"] = time.time() + 15      # while the next episode starts, getTime() may still show the old position: no popup again
        jsonrpc("Player.Open", {"item": {"episodeid": episode["episodeid"]}, "options": {"resume": False}})

    tick = 0
    while not monitor.waitForAbort(0.1):
        if xbmc.getSkinDir() == SKIN_ID:
            update_ring()
        if tick % 2 == 0:
            update_seek_target(player, xbmc.getSkinDir() == SKIN_ID and not skin_bool("video.noseekmark"))
        tick += 1
        if xbmc.getSkinDir() == SKIN_ID and tick % 2 == 0 and not player.isPlayingVideo():
            update_langs()
            update_rw()
            if xbmc.getCondVisibility("Window.IsActive(home)"):
                update_spot_langs()
                update_rw_home()
                update_rw_widget()
            else:
                _RW_HOME_LAST[0] = None
                _RW_WIDGET_LAST[0] = None
        if xbmc.getSkinDir() == SKIN_ID and tick % 3 == 0:
            player.remember_home_item()
        if xbmc.getSkinDir() == SKIN_ID and tick % 3 == 0:
            player.remember_lib_item()
        if player.lib_pending and xbmc.getSkinDir() == SKIN_ID:
            pend = player.lib_pending
            if (xbmcgui.getCurrentWindowId() == pend["window"] and xbmcgui.getCurrentWindowDialogId() == 9999
                    and not player.isPlaying()):
                if "since" not in pend:
                    pend["since"] = tick
                    pend["idle0"] = xbmc.getGlobalIdleTime()
                age = tick - pend["since"]
                if xbmc.getGlobalIdleTime() < pend["idle0"] + age * 0.1 - 0.8:
                    player.lib_pending = None   # the user pressed a key meanwhile: do not interfere
                elif age == 8:
                    # images of the played item can fail to load after a long playback (the red cross): reload the list once
                    xbmc.executebuiltin("Container.Refresh")
                elif age in (4, 12, 30):
                    if not (pend.get("dbtype") in ("episode", "season", "tvshow")
                            and xbmc.getCondVisibility("Skin.HasSetting(series.nolast)")):
                        focus_lib_item(pend, player.lib_play)
                elif age > 31:
                    player.lib_pending = None
            elif player.isPlaying() or time.time() - player.lib_stamp > 90:
                player.lib_pending = None
        if player.home_pending and xbmc.getSkinDir() == SKIN_ID:
            if xbmc.getCondVisibility("Window.IsActive(home)") and xbmcgui.getCurrentWindowDialogId() == 9999:
                pend = player.home_pending
                if "since" not in pend:
                    pend["since"] = tick
                    pend["idle0"] = xbmc.getGlobalIdleTime()
                    pend["good"] = 0
                age = tick - pend["since"]
                if xbmc.getGlobalIdleTime() < pend["idle0"] + age * 0.1 - 0.8:
                    player.home_pending = None   # the user pressed a key meanwhile: do not interfere
                elif age >= 4:
                    # keep the focus on the item while the widgets reload (the item may move in the list)
                    if home_item_focused(pend):
                        pend["good"] += 1
                    else:
                        pend["good"] = 0
                        focus_home_item(pend)
                    if pend["good"] >= 15 or age > 150:
                        player.home_pending = None
            elif player.isPlayingVideo() or player.isPlayingAudio():
                player.home_pending = None
        # while the Up Next popup is shown the countdown is updated on every pass (1 s steps would skip numbers)
        if tick % 10 == 5 and xbmc.getSkinDir() == SKIN_ID:   # option Wake up NAS disks: once per Kodi start / switch-on
            wake = skin_bool("nas.wake")
            if wake and not nas_woken:
                nas_woken = True
                start_nas_wake()
            elif not wake:
                nas_woken = False
        slow = tick % 10 == 0
        fast = state["shown"] and not state["dismissed"]
        if not slow and not fast:
            continue
        if slow and xbmc.getSkinDir() == SKIN_ID:
            configure_artistslideshow()
            update_slideshow()
            apply_views_after_first_init()
            apply_default_view()
        if xbmc.getSkinDir() != SKIN_ID or skin_bool("upnext.off") or not player.isPlayingVideo():
            if state["key"] is not None:
                reset()
            continue
        try:
            total = player.getTotalTime()
            position = player.getTime()
        except Exception:
            continue
        if total <= 0:
            continue
        item = current_episode() if slow else state.get("item")
        if not item:
            if state["key"] is not None:
                reset()
            continue
        key = (item["id"], xbmc.getInfoLabel("Player.Filenameandpath")) if slow else state["key"]
        if state["key"] != key:
            reset()
            state["key"] = key
            state["item"] = item
            state["next"] = find_next(item, not skin_bool("upnext.noseason"))
        episode = state["next"]
        if not episode:
            continue

        remaining = total - position
        show_before = skin_int("upnext.time", DEFAULT_TIME)
        countdown = skin_int("upnext.count", DEFAULT_COUNTDOWN)
        still_after = skin_int("upnext.still", DEFAULT_STILL)
        auto = not skin_bool("upnext.noauto")

        if state["dismissed"] or remaining > show_before or remaining < 0.5 or time.time() < state.get("cool", 0):
            if state["shown"] and remaining > show_before + 3:   # user seeked back
                close_dialog()
                state["dismissed"] = False
            continue

        ask_still = auto and still_after > 0 and player.auto_count + 1 >= still_after
        if not state["shown"]:
            state["shown"] = True
            state["t0"] = time.time()
            state["mode"] = "still" if ask_still else "next"
            art = episode.get("art", {})
            set_prop("thumb", art.get("thumb") or art.get("tvshow.fanart") or art.get("tvshow.poster", ""))
            set_prop("show", episode.get("showtitle", ""))
            set_prop("title", "S%02dE%02d  %s" % (episode.get("season", 0), episode.get("episode", 0), episode.get("title", "")))
            set_prop("se", "S%d:E%d" % (episode.get("season", 0), episode.get("episode", 0)))
            set_prop("etitle", episode.get("title", ""))
            set_prop("plot", episode.get("plot", ""))
            set_prop("mode", state["mode"])
            set_prop("sub", tr(32764) if state["mode"] == "still" else tr(32760))
            set_prop("action", "")
            xbmc.executebuiltin("ActivateWindow(%d)" % DIALOG_ID)
        elif not xbmc.getCondVisibility("Window.IsActive(%d)" % DIALOG_ID):
            state["dismissed"] = True       # popup closed with Back: keep watching, no automatic start
            clear_props()
            state["shown"] = False
            continue

        action = get_prop("action")
        if action == "more":   # "More info" was opened: no automatic start while reading
            state["hold"] = True
            set_prop("action", "")
            action = ""
        if action == "play":
            player.auto_count = 0
            play_next(False)
            continue
        if action == "stop":
            close_dialog()
            state["dismissed"] = True
            player.stop()
            continue

        waited = time.time() - state["t0"]
        if state["mode"] == "still":
            left = max(0, int(math.ceil(STILL_WAIT - waited)))
            set_prop("count", tr(32766) % left)
            set_prop("progress", int(100 * (1 - waited / STILL_WAIT)))
            if waited >= STILL_WAIT or remaining < 1.5:
                close_dialog()
                state["dismissed"] = True        # nobody answered: do not start the next episode
        else:
            left = max(0, int(math.ceil(countdown - waited)))
            set_prop("secs", left)
            if auto and not state["hold"]:
                set_prop("count", tr(32763) % left)
                set_prop("progress", int(100 * max(0.0, 1 - waited / max(1, countdown))))
                if waited >= countdown or remaining < 1.5:
                    play_next(True)
            else:
                set_prop("count", "")
                set_prop("progress", 0)


if __name__ == "__main__":
    run()
