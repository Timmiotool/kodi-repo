"""Trailer button of the info page: searches a trailer itself (TMDb + check on YouTube) instead of playing the link stored in the library."""
import json
import os
import re
import time
import unicodedata
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("skin.lumen")
CACHE_DAYS = 14
TIMEOUT = 8
# skin language index (strings 31600...) -> TMDb language code
NO_FALLBACK = "none"
DEFAULT_LANG = "de"
DEFAULT_LANG2 = "en"
TMDB_CODES = {"nb": "no"}


def jsonrpc(method, params):
    request = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
    try:
        return json.loads(xbmc.executeJSONRPC(request)).get("result", {}) or {}
    except Exception:
        return {}


def skin_string(name):
    return xbmc.getInfoLabel("Skin.String(%s)" % name).strip()


def notify(text_id):
    xbmcgui.Dialog().notification("Lumen", xbmc.getLocalizedString(text_id), xbmcgui.NOTIFICATION_INFO, 4000)


def http_json(url):
    request = urllib.request.Request(url, headers={"User-Agent": "Kodi-Lumen"})
    with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
        return json.loads(response.read().decode("utf-8"))


def item_info():
    """What the info page shows: kind (movie/tv), TMDb id (or None), title, year, stored trailer link."""
    dbtype = xbmc.getInfoLabel("ListItem.DBType")
    dbid = xbmc.getInfoLabel("ListItem.DBID")
    original = ""
    kind, uid, title, year, stored = "movie", {}, xbmc.getInfoLabel("ListItem.Title"), xbmc.getInfoLabel("ListItem.Year"), xbmc.getInfoLabel("ListItem.Trailer")
    try:
        dbid = int(dbid)
    except ValueError:
        dbid = -1
    if dbtype == "movie" and dbid > 0:
        d = jsonrpc("VideoLibrary.GetMovieDetails", {"movieid": dbid, "properties": ["uniqueid", "title", "originaltitle", "year", "trailer"]}).get("moviedetails", {})
        uid, title, year, stored = d.get("uniqueid", {}), d.get("title", title), str(d.get("year", year) or ""), d.get("trailer", stored)
        original = d.get("originaltitle", "")
    elif dbtype in ("tvshow", "season", "episode") and dbid > 0:
        kind = "tv"
        show = dbid if dbtype == "tvshow" else None
        if dbtype == "season":
            show = jsonrpc("VideoLibrary.GetSeasonDetails", {"seasonid": dbid, "properties": ["tvshowid"]}).get("seasondetails", {}).get("tvshowid")
        elif dbtype == "episode":
            show = jsonrpc("VideoLibrary.GetEpisodeDetails", {"episodeid": dbid, "properties": ["tvshowid"]}).get("episodedetails", {}).get("tvshowid")
        if show:
            d = jsonrpc("VideoLibrary.GetTVShowDetails", {"tvshowid": int(show), "properties": ["uniqueid", "title", "year", "trailer"]}).get("tvshowdetails", {})
            uid, title, year, stored = d.get("uniqueid", {}), d.get("title", title), str(d.get("year", "") or ""), d.get("trailer", stored)
    tmdb = (uid or {}).get("tmdb") or (uid or {}).get("themoviedb")
    return kind, str(tmdb) if tmdb else None, title, year, stored, original


def find_tmdb_id(key, kind, title, year):
    if not title:
        return None
    params = {"api_key": key, "query": title}
    if year:
        params["year" if kind == "movie" else "first_air_date_year"] = year
    data = http_json("https://api.themoviedb.org/3/search/%s?%s" % (kind, urllib.parse.urlencode(params)))
    results = data.get("results") or []
    return str(results[0]["id"]) if results else None


def youtube_alive(video):
    """False if YouTube reports the video as removed or private (embed info request fails)."""
    url = "https://www.youtube.com/oembed?format=json&url=" + urllib.parse.quote("https://www.youtube.com/watch?v=" + video, safe="")
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "Kodi-Lumen"})
        with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
            return response.status == 200
    except Exception as error:
        code = getattr(error, "code", None)
        return code not in (400, 401, 403, 404)   # network trouble: do not discard the candidate


def pick_video(videos, langs):
    """First usable YouTube trailer in the order of the languages (search language, fallback language, language-less), then teasers."""
    for wanted in ("Trailer", "Teaser"):
        for lang in langs:
            found = [v for v in videos if v.get("site") == "YouTube" and v.get("type") == wanted
                     and ((v.get("iso_639_1") or None) == lang)]
            found.sort(key=lambda v: (bool(v.get("official")), v.get("size") or 0, v.get("published_at") or ""), reverse=True)
            for v in found:
                if youtube_alive(v["key"]):
                    return v["key"]
    return None


CACHE_PATH = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/skin.lumen/"), "trailer_cache.json")


def cache_get(cache_key):
    try:
        with open(CACHE_PATH, "r", encoding="utf-8") as handle:
            entry = json.load(handle).get(cache_key)
        if entry and time.time() - entry.get("ts", 0) < CACHE_DAYS * 86400:
            return entry["video"]
    except Exception:
        pass
    return None


def cache_put(cache_key, video):
    cache = {}
    try:
        with open(CACHE_PATH, "r", encoding="utf-8") as handle:
            cache = json.load(handle)
    except Exception:
        pass
    cache[cache_key] = {"video": video, "ts": time.time()}
    try:
        os.makedirs(os.path.dirname(CACHE_PATH), exist_ok=True)
        with open(CACHE_PATH, "w", encoding="utf-8") as handle:
            json.dump(cache, handle)
    except Exception:
        pass


def search_tmdb(key, kind, tmdb, title, year, lang1, lang2):
    if not tmdb:
        tmdb = find_tmdb_id(key, kind, title, year)
    if not tmdb:
        return None
    codes = [TMDB_CODES.get(lang1, lang1)]
    if lang2 and lang2 != NO_FALLBACK and lang2 != lang1:
        codes.append(TMDB_CODES.get(lang2, lang2))
    cache_key = "tmdb:%s:%s:%s" % (kind, tmdb, ",".join(codes))
    video = cache_get(cache_key)
    if video:
        return video
    url = "https://api.themoviedb.org/3/%s/%s/videos?%s" % (kind, tmdb, urllib.parse.urlencode(
        {"api_key": key, "language": codes[0], "include_video_language": ",".join(codes + ["null"])}))
    video = pick_video(http_json(url).get("results") or [], codes + [None])
    if video:
        cache_put(cache_key, video)
    return video


# ---------------------------------------------------------------- direct YouTube search (no key needed)
# English language name, words that make a trailer of that language likely, words that mark a title as that language
LANG_INFO = {
    "de": ("German", "Trailer Deutsch", ("deutsch", "german", "dt.", "offizieller")),
    "en": ("English", "official trailer", ("official trailer",)),
    "fr": ("French", "bande annonce VF", ("bande-annonce", "bande annonce", "vf", "francais", "français")),
    "es": ("Spanish", "tráiler oficial español", ("espanol", "español", "tráiler", "trailer oficial", "castellano")),
    "it": ("Italian", "trailer ufficiale italiano", ("italiano", "ufficiale")),
    "pt": ("Portuguese", "trailer oficial legendado", ("dublado", "legendado", "oficial", "português", "portugues")),
    "nl": ("Dutch", "trailer Nederlands", ("nederlands", "nederlandse")),
    "pl": ("Polish", "zwiastun PL", ("zwiastun", "pl ", "polski")),
    "tr": ("Turkish", "fragman Türkçe", ("fragman", "turkce", "türkçe")),
    "ru": ("Russian", "трейлер на русском", ("трейлер", "русском", "дублированный")),
    "cs": ("Czech", "trailer CZ", ("cz", "cesky", "česky", "titulky")),
    "sk": ("Slovak", "trailer SK", ("sk", "slovensky")),
    "sv": ("Swedish", "trailer svenska", ("svenska", "svensk")),
    "da": ("Danish", "trailer dansk", ("dansk",)),
    "fi": ("Finnish", "traileri suomi", ("traileri", "suomi", "suomeksi")),
    "nb": ("Norwegian", "trailer norsk", ("norsk",)),
    "hu": ("Hungarian", "előzetes magyar", ("előzetes", "magyar", "szinkronos")),
    "ro": ("Romanian", "trailer subtitrat romana", ("subtitrat", "romana", "română")),
    "el": ("Greek", "τρέιλερ ελληνικά", ("τρέιλερ", "ελληνικ")),
    "uk": ("Ukrainian", "трейлер українською", ("трейлер", "українською")),
    "bg": ("Bulgarian", "трейлър бг", ("трейлър", "бг")),
    "hr": ("Croatian", "trailer hrvatski", ("hrvatski", "sinkronizirani")),
}
GOOD_CHANNELS = ("kinocheck", "warner", "universal", "sony pictures", "paramount", "disney", "netflix", "prime video", "20th century",
                 "lionsgate", "constantin", "studiocanal", "leonine", "concorde", "wild bunch", "a24", "neon", "hbo", "apple tv",
                 "movieclips trailers", "rotten tomatoes", "filmtrailer", "trailer", "universal pictures", "disney+", "magenta")
BAD_WORDS = ("reaction", "review", "kritik", "analyse", "analysis", "explained", "breakdown", "fan made", "fanmade", "fan trailer",
             "parody", "parodie", "spoof", "behind the scenes", "making of", "interview", "ending", "recap", "soundtrack", "theme",
             "full movie", "ganzer film", "film complet", "volledige film", "ending explained", "clip", "szene", "scene ", "ranking",
             "top 10", "top 5", "game", "gameplay", "lego", "tiktok", "shorts", "#shorts")


def norm(text):
    text = unicodedata.normalize("NFKD", (text or "").lower())
    text = "".join(c for c in text if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9\u0400-\u04ff\u0370-\u03ff ]+", " ", text)


def duration_seconds(text):
    try:
        parts = [int(p) for p in (text or "").split(":")]
    except ValueError:
        return None
    seconds = 0
    for part in parts:
        seconds = seconds * 60 + part
    return seconds


def youtube_results(query, lang):
    """Videos of the YouTube results page: (id, title, channel, seconds)."""
    country = {"en": "US", "de": "DE", "fr": "FR", "es": "ES", "it": "IT", "pt": "PT", "nl": "NL", "pl": "PL", "tr": "TR"}.get(lang, "")
    url = "https://www.youtube.com/results?search_query=%s&hl=%s%s" % (urllib.parse.quote(query), lang, ("&gl=" + country) if country else "")
    request = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36",
        "Accept-Language": "%s;q=0.9,en;q=0.7" % lang, "Cookie": "CONSENT=YES+1; SOCS=CAI"})
    with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
        html = response.read().decode("utf-8", "replace")
    match = re.search(r"var ytInitialData = (\{.*?\});</script>", html, re.S)
    if not match:
        return []
    found = []

    def walk(node):
        if isinstance(node, dict):
            renderer = node.get("videoRenderer")
            if renderer and renderer.get("videoId"):
                title = "".join(x.get("text", "") for x in renderer.get("title", {}).get("runs", []))
                owner = (renderer.get("ownerText", {}).get("runs") or [{}])[0].get("text", "")
                found.append((renderer["videoId"], title, owner, duration_seconds(renderer.get("lengthText", {}).get("simpleText"))))
            for child in node.values():
                walk(child)
        elif isinstance(node, list):
            for child in node:
                walk(child)
    walk(json.loads(match.group(1)))
    return found


def score_result(result, names, year, lang):
    """Higher is better; None = not about this title."""
    video, title, channel, seconds = result
    t = norm(title)
    wanted = [norm(n) for n in names if n]
    if not any(w and w.strip() in t for w in wanted):
        # tolerate small differences: most of the title words must appear
        best = 0.0
        for w in wanted:
            words = [x for x in w.split() if len(x) > 1]
            if words:
                best = max(best, sum(1 for x in words if x in t.split()) / len(words))
        if best < 0.8:
            return None
    points = 0
    if any(k in t for k in ("trailer", "teaser", "zwiastun", "fragman", "tráiler", "traileri", "bande annonce", "bande-annonce", "трейлер", "τρέιλερ", "előzetes", "treiler")):
        points += 3
    else:
        points -= 2
    if "offiziell" in t or "official" in t or "ufficiale" in t or "oficial" in t or "officiel" in t:
        points += 2
    if year:
        years = re.findall(r"(?<![0-9])((?:19|20)[0-9][0-9])(?![0-9])", t)
        if any(abs(int(y) - int(year)) <= 1 for y in years if year.isdigit()):
            points += 2
        elif years and year.isdigit():
            points -= 8          # another film of the same name / another year (e.g. a remake)
    c = norm(channel)
    if any(g in c for g in GOOD_CHANNELS):
        points += 3
    if any(bad in (t + " ") for bad in BAD_WORDS):
        points -= 6
    if seconds is not None:
        points += 2 if 45 <= seconds <= 300 else (-4 if seconds > 420 else (-3 if seconds < 30 else 0))
    own = LANG_INFO.get(lang, ("", "", ()))[2]
    if own and any(m in t for m in own):
        points += 4
    if lang == "en":
        for other, info in LANG_INFO.items():
            if other != "en" and any(m in t for m in info[2] if len(m) > 3):
                points -= 4
                break
    return points


def name_variants(name):
    """The title and shorter forms of it (part after a dash, part before a colon)."""
    out = [name]
    for sep in (" - ", ": ", " – "):
        if sep in name:
            for part in name.split(sep):
                if len(norm(part).split()) >= 2 and part not in out:
                    out.append(part)
    return out


def search_youtube(kind, title, original, year, lang1, lang2):
    languages = [lang1] + ([lang2] if lang2 and lang2 != NO_FALLBACK and lang2 != lang1 else [])
    cache_key = "yt2:%s:%s:%s:%s" % (kind, norm(title), year, ",".join(languages))
    video = cache_get(cache_key)
    if video:
        return video
    # the title shown in the library first; the original title only when that finds nothing
    for name in [title] + ([original] if original and norm(original) != norm(title) else []):
        variants = name_variants(name)
        candidates = {}
        for lang in languages:
            words = LANG_INFO.get(lang, (lang, "trailer", ()))[1]
            query = re.sub(r"\s+", " ", "%s %s %s" % (name, year if kind == "movie" else "", words)).strip()
            try:
                results = youtube_results(query, lang)
            except Exception as error:
                xbmc.log("Lumen YouTube search failed: %s" % error, xbmc.LOGINFO)
                continue
            for result in results[:20]:
                points = score_result(result, variants, year, lang)
                if points is not None and points >= 5 and (result[0] not in candidates or candidates[result[0]] < points):
                    candidates[result[0]] = points
        for video, points in sorted(candidates.items(), key=lambda c: c[1], reverse=True)[:4]:
            if youtube_alive(video):
                cache_put(cache_key, video)
                return video
    return None

def launch(url):
    """Closes the info dialog (like the Kodi trailer button does) and plays the trailer in full screen, not behind the dialog."""
    xbmc.executebuiltin("Dialog.Close(all,true)")
    xbmc.sleep(300)
    xbmc.executebuiltin('PlayMedia("%s")' % url)
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    waited = 0.0
    while waited < 20 and not monitor.abortRequested():
        if player.isPlayingVideo():
            break
        monitor.waitForAbort(0.25)
        waited += 0.25
    if player.isPlayingVideo() and not xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
        xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")


def play_stored(stored):
    if stored:
        launch(stored)
        return True
    return False


def run():
    kind, tmdb, title, year, stored, original = item_info()
    source = skin_string("trailer.src") or "yt"        # tmdb | yt | both
    key = skin_string("trailer.key")
    lang1 = skin_string("trailer.lang") or DEFAULT_LANG
    lang2 = skin_string("trailer.lang2") or DEFAULT_LANG2
    if source == "tmdb" and not key:
        notify(31673)
        play_stored(stored)
        return
    if not xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.youtube)"):
        notify(31674)
        play_stored(stored)
        return
    video = None
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        if source in ("tmdb", "both") and key:
            try:
                video = search_tmdb(key, kind, tmdb, title, year, lang1, lang2)
            except Exception as error:
                xbmc.log("Lumen trailer search (TMDb) failed: %s" % error, xbmc.LOGINFO)
        if not video and source in ("yt", "both"):
            try:
                video = search_youtube(kind, title, original, year, lang1, lang2)
            except Exception as error:
                xbmc.log("Lumen trailer search (YouTube) failed: %s" % error, xbmc.LOGINFO)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if video:
        launch("plugin://plugin.video.youtube/play/?video_id=%s" % video)
    else:
        notify(31672)
        play_stored(stored)

def edit_key():
    """Click on the TMDb key row: enter it, or choose Change / Delete when one is stored."""
    if not skin_string("trailer.key"):
        xbmc.executebuiltin("Skin.SetString(trailer.key)")
        return
    heading = xbmc.getLocalizedString(31668)
    choice = xbmcgui.Dialog().select(heading, [xbmc.getLocalizedString(31680), xbmc.getLocalizedString(31681)])
    if choice == 0:
        xbmc.executebuiltin("Skin.SetString(trailer.key)")    # keyboard with the stored key to edit
    elif choice == 1:
        xbmc.executebuiltin("Skin.Reset(trailer.key)")
