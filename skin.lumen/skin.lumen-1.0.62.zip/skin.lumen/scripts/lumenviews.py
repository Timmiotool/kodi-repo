"""Lumen standard views: applies the default view of each content type to paths that have no saved view yet.

Kodi stores the chosen view per path in ViewModes6.db. The service calls apply() once per newly opened path;
an existing row (the user's own choice) is never changed. The default view per content type is a skin setting
(Lumen configuration > Views & lists > Default view). apply_all() switches every saved Lumen view to the defaults
(used by the "Apply to all lists" button, "Reset all" and a fresh installation).
"""
import re
import sqlite3

import xbmc
import xbmcvfs

SKIN_ID = "skin.lumen"

# window -> Container.Content -> (skin setting, built-in fallback view control id); "" = everything else
SETTING_VIEWS = {
    10025: {
        "movies": ("view.def.movies", 57),
        "sets": ("view.def.movies", 57),
        "musicvideos": ("view.def.musicvideos", 57),
        "tvshows": ("view.def.tvshows", 57),
        "seasons": ("view.def.seasons", 57),
        "episodes": ("view.def.episodes", 57),
        "": ("view.def.vother", 52),
    },
    10502: {
        "artists": ("view.def.artists", 53),
        "albums": ("view.def.albums", 53),
        "songs": ("view.def.songs", 52),
        "": ("view.def.mother", 53),
    },
    10002: {"": ("view.def.pictures", 50)},
    10001: {"": ("view.def.addons", 51)},
    10040: {"": ("view.def.addons", 51)},
    10060: {"": ("view.def.favs", 50)},
}
DEFAULT_VIEWS = SETTING_VIEWS
ROOT_SONGS = "musicdb://songs/"
# views that earlier Lumen versions set automatically; such rows were never chosen by the user
LEGACY_DEFAULTS = {"seasons": 56, "episodes": 52}

# Kodi stores (viewtype << 16) | control id; the viewtype comes from the <viewtype> of the control (list 1, icon 2, biglist 3)
_VIEW_TYPES = {
    10025: {50: 1, 51: 3, 52: 3, 53: 1, 54: 1, 55: 3, 56: 1, 57: 3},
    10502: {50: 1, 51: 3, 52: 3, 53: 3, 54: 1, 55: 3},
    10002: {50: 1, 51: 3},
    10001: {50: 1, 51: 3},
    10040: {50: 1, 51: 3},
    10060: {50: 2, 51: 1},
}

_VIDEO_RULES = (
    (re.compile(r"^videodb://musicvideos(/|$)"), "musicvideos"),
    (re.compile(r"^videodb://(movies|recentlyaddedmovies|inprogressmovies)(/|$)"), "movies"),
    (re.compile(r"^videodb://tvshows/(titles/)?(\?.*)?$"), "tvshows"),
    (re.compile(r"^videodb://tvshows/titles/\d+/(\?.*)?$"), "seasons"),
    (re.compile(r"^videodb://tvshows/titles/\d+/-?\d+/"), "episodes"),
    (re.compile(r"^videodb://(recentlyaddedepisodes|inprogresstvshows)/"), "episodes"),
)
_MUSIC_RULES = (
    (re.compile(r"^musicdb://artists/(\?.*)?$"), "artists"),
    (re.compile(r"^musicdb://albums/(\?.*)?$"), "albums"),
    (re.compile(r"^musicdb://artists/\d+/(\?.*)?$"), "albums"),
    (re.compile(r"^musicdb://songs/"), "songs"),
    (re.compile(r"^musicdb://(albums|artists)/\d+/.*"), "songs"),
)
_RULES = {10025: _VIDEO_RULES, 10502: _MUSIC_RULES}

# Individual views of the reference installation for generic (not installation specific) paths:
# (window, path) -> (view control id, sortMethod, sortOrder[, sortAttributes]). Applied by apply_all() and used for new paths.
VIEW_SEEDS = {
    (10025, "sources://video/"): (52, 2, 2),
    (10025, "videodb://movies/"): (52, 0, 0),
    (10025, "videodb://movies/titles/"): (57, 29, 1, 1),
    (10025, "videodb://movies/titles/?xsp=%7B%22rules%22%3A%7B%22and%22%3A%5B%7B%22field%22%3A%22inprogress%22%2C%22operator%22%3A%22true%22%2C%22value%22%3A%22%22%7D%5D%7D%2C%22type%22%3A%22movies%22%7D"): (57, 29, 1, 1),
    (10025, "videodb://movies/titles/?xsp=%7b%22order%22%3a%7b%22direction%22%3a%22ascending%22%2c%22ignorefolders%22%3a0%2c%22method%22%3a%22sorttitle%22%7d%2c%22type%22%3a%22movies%22%7d"): (57, 29, 1, 1),
    (10025, "videodb://recentlyaddedmovies/"): (57, 0, 0),
    (10025, "videodb://tvshows/"): (57, 0, 0),
    (10025, "videodb://tvshows/titles/"): (57, 29, 1, 1),
    (10025, "videodb://tvshows/titles/?xsp=%7b%22order%22%3a%7b%22direction%22%3a%22ascending%22%2c%22ignorefolders%22%3a0%2c%22method%22%3a%22sorttitle%22%7d%2c%22rules%22%3a%7b%22and%22%3a%5b%5d%7d%2c%22type%22%3a%22tvshows%22%7d"): (57, 29, 1, 1),
    (10040, "addons://"): (50, 0, 0),
    (10040, "addons://all/"): (51, 1, 1, 2),
    (10040, "addons://all/kodi.pvrclient/"): (51, 1, 1, 2),
    (10040, "addons://all/xbmc.gui.skin/"): (51, 1, 1, 2),
    (10040, "addons://recently_updated/"): (51, 51, 2, 2),
    (10040, "addons://repos/"): (51, 1, 1, 2),
    (10040, "addons://repository.xbmc.org/"): (51, 1, 1, 2),
    (10040, "addons://repository.xbmc.org/category.lookandfeel/"): (51, 1, 1, 2),
    (10040, "addons://repository.xbmc.org/kodi.pvrclient/"): (51, 1, 1, 2),
    (10040, "addons://repository.xbmc.org/kodi.resource.images/"): (51, 1, 1, 2),
    (10040, "addons://repository.xbmc.org/xbmc.addon.audio/"): (51, 1, 1, 2),
    (10040, "addons://repository.xbmc.org/xbmc.addon.image/"): (51, 1, 1, 2),
    (10040, "addons://repository.xbmc.org/xbmc.addon.video/"): (51, 1, 1, 2),
    (10040, "addons://repository.xbmc.org/xbmc.gui.skin/"): (51, 1, 1, 2),
    (10040, "addons://sources/executable/"): (51, 1, 1, 2),
    (10040, "addons://sources/video/"): (52, 1, 1, 2),
    (10040, "addons://user/"): (51, 1, 1, 2),
    (10040, "addons://user/all/"): (51, 1, 1, 2),
    (10040, "addons://user/category.lookandfeel/"): (51, 1, 1, 2),
    (10040, "addons://user/kodi.pvrclient/"): (51, 1, 1, 2),
    (10040, "addons://user/xbmc.gui.skin/"): (51, 1, 1, 2),
    (10060, "favourites://"): (50, 59, 1),
    (10502, "/"): (54, 0, 0),
    (10502, "musicdb://albums/"): (53, 12, 1, 1),
    (10502, "musicdb://artists/"): (53, 10, 1, 1),
    (10502, "musicdb://songs/"): (52, 8, 1),
}
_done = set()


def _db_path():
    return xbmcvfs.translatePath("special://profile/Database/ViewModes6.db")


def _norm(path):
    if path and "?" not in path and not path.endswith("/"):
        path += "/"
    return path


def _saved_view(window, path):
    """Return the control id of the saved Lumen view for this path (None: nothing saved, -1: unknown)."""
    try:
        con = sqlite3.connect(_db_path(), timeout=2)
        try:
            row = con.execute("SELECT viewMode FROM view WHERE window=? AND path=? AND skin=? "
                              "ORDER BY idView DESC LIMIT 1", (window, _norm(path), SKIN_ID)).fetchone()
        finally:
            con.close()
        return (row[0] & 0xFFFF) if row else None
    except Exception:
        return -1


def _setting_view(window, content):
    table = SETTING_VIEWS[window]
    key, fallback = table.get(content, table[""])
    value = xbmc.getInfoLabel("Skin.String(%s)" % key)
    return int(value) if value.isdigit() else fallback


def _content_of_path(window, path):
    for rx, content in _RULES.get(window, ()):
        if rx.match(path):
            return content
    return ""


def apply(window_id):
    """Set the default view for the currently shown container if the user never chose one."""
    if window_id not in SETTING_VIEWS:
        return
    path = xbmc.getInfoLabel("Container.FolderPath")
    if not path or (window_id, path) in _done:
        return
    _done.add((window_id, path))
    content = xbmc.getInfoLabel("Container.Content")
    if window_id == 10502 and _norm(path) == ROOT_SONGS:
        content = "songs"
    saved = _saved_view(window_id, path)
    if saved == -1:
        return
    seed = VIEW_SEEDS.get((window_id, _norm(path)))
    view = seed[0] if seed else _setting_view(window_id, content)
    if saved is not None and not (saved == LEGACY_DEFAULTS.get(content) and view != saved):
        return
    if view and xbmc.getInfoLabel("Container.Viewmode") != "" and \
            not xbmc.getCondVisibility("Control.IsVisible(%d)" % view):
        xbmc.executebuiltin("Container.SetViewMode(%d)" % view)


def apply_all():
    """Switch every saved Lumen view (also individually chosen ones) to the current default views.

    Only the view is changed; sorting stays as it is. Returns the number of changed lists (-1 on error).
    """
    changed = 0
    try:
        con = sqlite3.connect(_db_path(), timeout=5)
        try:
            for window in SETTING_VIEWS:
                rows = con.execute("SELECT idView, path, viewMode FROM view WHERE window=? AND skin=?",
                                   (window, SKIN_ID)).fetchall()
                for id_view, path, mode in rows:
                    seed = VIEW_SEEDS.get((window, _norm(path)))
                    view = seed[0] if seed else _setting_view(window, _content_of_path(window, path))
                    target = (_VIEW_TYPES[window].get(view, 1) << 16) | view
                    if target != mode:
                        con.execute("UPDATE view SET viewMode=? WHERE idView=?", (target, id_view))
                        changed += 1
            for (window, path), (view, method, order, *attr) in VIEW_SEEDS.items():
                if con.execute("SELECT 1 FROM view WHERE window=? AND path=? AND skin=?", (window, path, SKIN_ID)).fetchone() is None:
                    mode = (_VIEW_TYPES[window].get(view, 1) << 16) | view
                    con.execute("INSERT INTO view (window, path, viewMode, sortMethod, sortOrder, sortAttributes, skin) VALUES (?,?,?,?,?,?,?)", (window, path, mode, method, order, attr[0] if attr else 0, SKIN_ID))
                    changed += 1
            con.commit()
        finally:
            con.close()
    except Exception:
        return -1
    _done.clear()
    return changed


def reset_views():
    try:
        con = sqlite3.connect(_db_path(), timeout=5)
        try:
            con.execute("DELETE FROM view WHERE skin=?", (SKIN_ID,))
            con.commit()
        finally:
            con.close()
    except Exception:
        pass
    _done.clear()