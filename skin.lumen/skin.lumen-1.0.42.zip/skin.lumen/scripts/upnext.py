"""Lumen Up Next: Netflix style "play next episode" popup for the video player.

Runs as a background service (xbmc.service extension of the skin). Options are Lumen skin settings
(Skin.HasSetting / Skin.String) so they can be changed in the Lumen configuration.
"""
import json
import time

import xbmc
import xbmcaddon
import xbmcgui

import lumenviews

HOME = 10000
DIALOG_ID = 1109
SKIN_ID = "skin.lumen"
PREFIX = "lumen.upnext."

DEFAULT_TIME = 30       # show the popup this many seconds before the end
DEFAULT_COUNTDOWN = 15  # seconds between popup and automatic start
DEFAULT_STILL = 3       # ask "still watching?" after this many automatic episodes
STILL_WAIT = 30         # seconds to wait for an answer to "still watching?"


def tr(string_id):
    return xbmc.getInfoLabel("$LOCALIZE[%d]" % string_id)


def jsonrpc(method, params=None):
    query = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        query["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(query))).get("result", {}) or {}
    except Exception:
        return {}


def skin_bool(name):
    return xbmc.getCondVisibility("Skin.HasSetting(%s)" % name)


def skin_int(name, default):
    value = xbmc.getInfoLabel("Skin.String(%s)" % name).strip()
    try:
        return int(value)
    except ValueError:
        return default


def set_prop(name, value):
    xbmcgui.Window(HOME).setProperty(PREFIX + name, str(value))


def get_prop(name):
    return xbmcgui.Window(HOME).getProperty(PREFIX + name)


def clear_props():
    for name in ("title", "sub", "show", "thumb", "count", "mode", "progress", "action"):
        xbmcgui.Window(HOME).clearProperty(PREFIX + name)


def handle(action):
    """Called from the dialog buttons (RunScript(skin.lumen,upnext_<action>))."""
    set_prop("action", action)


class UpNextPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.auto_started = False
        self.auto_count = 0

    def onAVStarted(self):
        if self.auto_started:
            self.auto_count += 1
        else:
            self.auto_count = 0
        self.auto_started = False

BAR_WIDTH = 1720        # width of the seek bar in the skin (pixels)
BAR_STEP = 17           # coarse step of the marker animation in the skin


def parse_time(text):
    """'1:02:03' / '02:03' -> seconds, None if it is not a time."""
    try:
        parts = [int(p) for p in text.strip().split(":")]
    except ValueError:
        return None
    seconds = 0
    for part in parts:
        seconds = seconds * 60 + part
    return seconds


def clear_seek_target():
    window = xbmcgui.Window(HOME)
    window.clearProperty(PREFIX + "seekc")
    window.clearProperty(PREFIX + "seekf")


def update_seek_target(player, enabled):
    """While the user is seeking (e.g. pressing a skip key several times) show the target position on the bar."""
    if not enabled or not player.isPlayingVideo():
        clear_seek_target()
        return
    if not xbmc.getCondVisibility("Player.Seeking | Player.HasPerformedSeek(2)"):
        clear_seek_target()
        return
    target = parse_time(xbmc.getInfoLabel("Player.SeekTime"))
    try:
        total = player.getTotalTime()
    except Exception:
        total = 0
    if target is None or total <= 0:
        clear_seek_target()
        return
    pixels = max(0, min(BAR_WIDTH, int(BAR_WIDTH * target / total)))
    set_prop("seekc", pixels // BAR_STEP)
    set_prop("seekf", pixels % BAR_STEP)

RING_FRAMES = 72
RING_SECONDS = 14.0


def update_ring():
    """Frame animation of the logo ring (a rotate animation would turn the circle into an ellipse on non 16:9 screens)."""
    if xbmc.getCondVisibility("Window.IsActive(1110) | Control.HasFocus(108) | Control.HasFocus(4010)"):
        frame = int((time.time() % RING_SECONDS) / RING_SECONDS * RING_FRAMES) % RING_FRAMES
        set_prop("ringtex", "special://skin/media/ring_%02d.png" % frame)

# Artist Slideshow settings of the Lumen reference installation (applied once after installation)
SLIDESHOW_SETTINGS = {
    "fanarttv": "true",
    "theaudiodb": "true",
    "ai_theaudiodb": "true",
    "ai_lastfm": "true",
    "language": "16",
    "ab_theaudiodb": "true",
    "ab_lastfm": "true",
    "sa_lastfm": "true",
}


def configure_artistslideshow():
    """Apply the reference settings to Artist Slideshow once, if it is installed and was not configured by Lumen before."""
    if xbmc.getCondVisibility("Skin.HasSetting(lumen.asinit)"):
        return
    if not xbmc.getCondVisibility("System.HasAddon(script.artistslideshow)"):
        return
    try:
        addon = xbmcaddon.Addon("script.artistslideshow")
        for key, value in SLIDESHOW_SETTINGS.items():
            addon.setSetting(key, value)
    except Exception:
        return
    xbmc.executebuiltin("Skin.SetBool(lumen.asinit)")

SLIDESHOW = {"started": False}


_fresh = {"seen": False}


def apply_views_after_first_init():
    """On a fresh installation the skin defaults are set when the first window loads (lumen.init false -> true).
    Right after that, switch all saved Lumen views to the default views."""
    if not skin_bool("lumen.init"):
        _fresh["seen"] = True
    elif _fresh["seen"]:
        _fresh["seen"] = False
        lumenviews.apply_all()

def apply_default_view():
    """Give new paths the Lumen standard view (see lumenviews.py)."""
    window = xbmcgui.getCurrentWindowId()
    if window in lumenviews.DEFAULT_VIEWS:
        lumenviews.apply(window)


def update_slideshow():
    """Start Artist Slideshow while music from the library plays, so the home screen has images before the player is opened."""
    if not xbmc.getCondVisibility("Player.HasAudio"):
        SLIDESHOW["started"] = False
        return
    if SLIDESHOW["started"]:
        return
    if xbmc.getCondVisibility("!Player.HasVideo + !String.IsEmpty(MusicPlayer.DBID) + !Skin.HasSetting(music.nofanart) + "
                              "!Skin.HasSetting(home.nonowplaying) + System.AddonIsEnabled(script.artistslideshow)"):
        SLIDESHOW["started"] = True
        xbmc.executebuiltin("RunScript(script.artistslideshow)")

def current_episode():
    """Info about the playing episode or None (only library episodes are handled)."""
    result = jsonrpc("Player.GetItem", {"playerid": 1, "properties": [
        "tvshowid", "season", "episode", "showtitle", "title", "playcount"]})
    item = result.get("item", {})
    if item.get("type") != "episode" or item.get("id", -1) < 0 or item.get("tvshowid", -1) < 0:
        return None
    return item


def find_next(item, allow_next_season):
    result = jsonrpc("VideoLibrary.GetEpisodes", {
        "tvshowid": item["tvshowid"],
        "properties": ["season", "episode", "title", "showtitle", "art", "playcount", "runtime"],
        "sort": {"method": "episode", "order": "ascending"}})
    here = (item.get("season", 0), item.get("episode", 0))
    best = None
    for ep in result.get("episodes", []):
        key = (ep.get("season", 0), ep.get("episode", 0))
        if key <= here:
            continue
        if ep.get("season", 0) == 0 and here[0] != 0:
            continue
        if not allow_next_season and key[0] != here[0]:
            continue
        if best is None or key < (best.get("season", 0), best.get("episode", 0)):
            best = ep
    return best


def run():
    monitor = xbmc.Monitor()
    player = UpNextPlayer()
    xbmcgui.Window(HOME).setProperty(PREFIX + "alive", "1")
    state = {"key": None, "next": None, "shown": False, "dismissed": False, "t0": 0.0, "mode": None}

    def close_dialog():
        if xbmc.getCondVisibility("Window.IsActive(%d)" % DIALOG_ID):
            xbmc.executebuiltin("Dialog.Close(%d)" % DIALOG_ID)
        clear_props()
        state["shown"] = False

    def reset():
        if state["shown"]:
            close_dialog()
        state.update({"key": None, "next": None, "shown": False, "dismissed": False, "mode": None})

    def play_next(auto):
        episode = state["next"]
        item = state.get("item") or {}
        close_dialog()
        state["dismissed"] = True
        if not episode:
            return
        try:
            total = player.getTotalTime()
            if total > 0 and player.getTime() / total < 0.9 and item.get("id", -1) >= 0:
                jsonrpc("VideoLibrary.SetEpisodeDetails", {
                    "episodeid": item["id"], "playcount": item.get("playcount", 0) + 1,
                    "resume": {"position": 0, "total": 0}})
        except Exception:
            pass
        player.auto_started = auto
        jsonrpc("Player.Open", {"item": {"episodeid": episode["episodeid"]}, "options": {"resume": False}})

    tick = 0
    while not monitor.waitForAbort(0.1):
        if xbmc.getSkinDir() == SKIN_ID:
            update_ring()
        if tick % 2 == 0:
            update_seek_target(player, xbmc.getSkinDir() == SKIN_ID and not skin_bool("video.noseekmark"))
        tick += 1
        if tick % 10:
            continue
        if xbmc.getSkinDir() == SKIN_ID:
            configure_artistslideshow()
            update_slideshow()
            apply_views_after_first_init()
            apply_default_view()
        if xbmc.getSkinDir() != SKIN_ID or skin_bool("upnext.off") or not player.isPlayingVideo():
            if state["key"] is not None:
                reset()
            continue
        try:
            total = player.getTotalTime()
            position = player.getTime()
        except Exception:
            continue
        if total <= 0:
            continue
        item = current_episode()
        if not item:
            if state["key"] is not None:
                reset()
            continue
        key = (item["id"], xbmc.getInfoLabel("Player.Filenameandpath"))
        if state["key"] != key:
            reset()
            state["key"] = key
            state["item"] = item
            state["next"] = find_next(item, not skin_bool("upnext.noseason"))
        episode = state["next"]
        if not episode:
            continue

        remaining = total - position
        show_before = skin_int("upnext.time", DEFAULT_TIME)
        countdown = skin_int("upnext.count", DEFAULT_COUNTDOWN)
        still_after = skin_int("upnext.still", DEFAULT_STILL)
        auto = not skin_bool("upnext.noauto")

        if state["dismissed"] or remaining > show_before or remaining < 0.5:
            if state["shown"] and remaining > show_before + 3:   # user seeked back
                close_dialog()
                state["dismissed"] = False
            continue

        ask_still = auto and still_after > 0 and player.auto_count + 1 >= still_after
        if not state["shown"]:
            state["shown"] = True
            state["t0"] = time.time()
            state["mode"] = "still" if ask_still else "next"
            art = episode.get("art", {})
            set_prop("thumb", art.get("thumb") or art.get("tvshow.fanart") or art.get("tvshow.poster", ""))
            set_prop("show", episode.get("showtitle", ""))
            set_prop("title", "S%02dE%02d  %s" % (episode.get("season", 0), episode.get("episode", 0), episode.get("title", "")))
            set_prop("mode", state["mode"])
            set_prop("sub", tr(32764) if state["mode"] == "still" else tr(32760))
            set_prop("action", "")
            xbmc.executebuiltin("ActivateWindow(%d)" % DIALOG_ID)
        elif not xbmc.getCondVisibility("Window.IsActive(%d)" % DIALOG_ID):
            state["dismissed"] = True       # popup closed with Back: keep watching, no automatic start
            clear_props()
            state["shown"] = False
            continue

        action = get_prop("action")
        if action == "play":
            player.auto_count = 0
            play_next(False)
            continue
        if action == "stop":
            close_dialog()
            state["dismissed"] = True
            player.stop()
            continue

        waited = time.time() - state["t0"]
        if state["mode"] == "still":
            left = max(0, int(STILL_WAIT - waited))
            set_prop("count", tr(32766) % left)
            set_prop("progress", int(100 * (1 - waited / STILL_WAIT)))
            if waited >= STILL_WAIT or remaining < 1.5:
                close_dialog()
                state["dismissed"] = True        # nobody answered: do not start the next episode
        else:
            left = max(0, int(round(countdown - waited)))
            if auto:
                set_prop("count", tr(32763) % left)
                set_prop("progress", int(100 * max(0.0, 1 - waited / max(1, countdown))))
                if waited >= countdown or remaining < 1.5:
                    play_next(True)
            else:
                set_prop("count", "")
                set_prop("progress", 0)


if __name__ == "__main__":
    run()