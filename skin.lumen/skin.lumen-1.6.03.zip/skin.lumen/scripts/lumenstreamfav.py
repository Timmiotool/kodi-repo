"""Stream info page: "Add to favourites" / "Remove from favourites" for the item shown in the video info dialog.

Kodi's Favourites.AddFavourite adds the item or removes it again if it already is a favourite. The window property
lumen.stream.fav ("1" = is a favourite) decides which of the two buttons the info page shows.
"""
import json

import xbmc
import xbmcgui

HOME = xbmcgui.Window(10000)
PROP = "lumen.stream.fav"


def _rpc(method, params=None):
    request = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        request["params"] = params
    return json.loads(xbmc.executeJSONRPC(json.dumps(request)))


def _item():
    """What a favourite of the shown item looks like: shows and seasons open their folder, everything else plays."""
    label = xbmc.getInfoLabel
    dbtype = label("ListItem.DBType")
    title = label("ListItem.Title") or label("ListItem.Label")
    thumb = label("ListItem.Art(poster)") or label("ListItem.Art(thumb)") or label("ListItem.Icon")
    if dbtype in ("tvshow", "season"):
        path = label("ListItem.FolderPath")
        return {"title": title, "thumbnail": thumb, "type": "window", "window": "videos",
                "windowparameter": path, "match": path}
    path = label("ListItem.FileNameAndPath") or label("ListItem.Path")
    return {"title": title, "thumbnail": thumb, "type": "media", "path": path, "match": path}


def _is_favourite(item):
    result = _rpc("Favourites.GetFavourites", {"properties": ["path", "windowparameter"]})
    for fav in (result.get("result") or {}).get("favourites") or []:
        if item["match"] and item["match"] in (fav.get("path"), fav.get("windowparameter")):
            return True
    return False


def check():
    """Set the property for the shown item (called when the info page opens)."""
    item = _item()
    if item["match"] and _is_favourite(item):
        HOME.setProperty(PROP, "1")
    else:
        HOME.clearProperty(PROP)


def toggle():
    item = _item()
    if not item["match"]:
        return
    params = {k: v for k, v in item.items() if k != "match" and v}
    _rpc("Favourites.AddFavourite", params)
    check()
