"""Seasons list: focus the season of the episode played most recently (also partly watched), once per opened show."""
import re
import json

import xbmc
import xbmcgui

HOME = xbmcgui.Window(10000)
PROP = "lumen.seasonpath"


def _rpc(method, params):
    request = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request)))


def focus(container_id):
    path = xbmc.getInfoLabel("Container.FolderPath")
    match = re.match(r"^videodb://tvshows/titles/(\d+)/?(\?.*)?$", path or "")
    if not match:
        return
    # run only once per opened show; going back from the episodes keeps the position Kodi restores
    if HOME.getProperty(PROP) == path:
        return
    result = _rpc("VideoLibrary.GetEpisodes", {"tvshowid": int(match.group(1)),
                                               "properties": ["season", "lastplayed"],
                                               "sort": {"method": "lastplayed", "order": "descending"},
                                               "limits": {"start": 0, "end": 1}})
    episodes = (result.get("result") or {}).get("episodes") or []
    played = [e for e in episodes if e.get("lastplayed") and e.get("season", 0) >= 0]
    HOME.setProperty(PROP, path)
    if not played:
        return
    target = str(played[0]["season"])
    cid = int(container_id)
    count = 0
    for _ in range(30):  # wait until the list is filled
        count = int(xbmc.getInfoLabel("Container.NumItems") or 0)
        if count > 1 and xbmc.getInfoLabel("Container.FolderPath") == path:
            break
        xbmc.sleep(100)
    for index in range(count + 1):  # NumItems does not count the parent ("..") item
        if xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Season" % (cid, index)) == target:
            xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, index))
            return