import xbmc
import xbmcaddon

import rpi_brightness


class SettingsMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        # Regler im Einstellungsdialog veraendert: sofort anwenden
        rpi_brightness.apply_brightness(xbmcaddon.Addon().getSetting("brightness"))


def main():
    monitor = SettingsMonitor()
    monitor.waitForAbort(5)  # wait for system to be ready
    addon = xbmcaddon.Addon()
    if addon.getSettingBool("apply_on_startup"):
        rpi_brightness.apply_brightness(addon.getSetting("brightness"))
    else:
        xbmc.log("[RPI Brightness] Startup brightness setting disabled.", xbmc.LOGINFO)
    while not monitor.abortRequested():
        if monitor.waitForAbort(60):
            break


if __name__ == "__main__":
    main()