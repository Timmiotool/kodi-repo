import xbmcaddon
import xbmcgui

import rpi_brightness


def main():
    addon = xbmcaddon.Addon()
    # Regler (50-255) im Einstellungsdialog; blockiert, bis der Dialog geschlossen wird
    addon.openSettings()

    addon = xbmcaddon.Addon()  # frisch lesen
    brightness = rpi_brightness.clamp(addon.getSetting("brightness"))
    ok, message = rpi_brightness.apply_brightness(brightness)
    addon.setSetting("brightness", str(brightness))
    if ok:
        text = str(brightness) + (" (%s)" % message if message else "")
        xbmcgui.Dialog().notification(addon.getLocalizedString(30003), text, xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification(addon.getLocalizedString(30004), message, xbmcgui.NOTIFICATION_ERROR)


if __name__ == "__main__":
    main()