import os

import xbmc

BACKLIGHT_DIR = "/sys/class/backlight"
PREFERRED_DEVICE = "rpi_backlight"
MIN_BRIGHTNESS = 50
MAX_BRIGHTNESS = 255
DEFAULT_BRIGHTNESS = 200


def clamp(value):
    try:
        value = int(value)
    except (TypeError, ValueError):
        value = DEFAULT_BRIGHTNESS
    return max(MIN_BRIGHTNESS, min(MAX_BRIGHTNESS, value))


def is_simulated():
    # Auf Windows (Testsystem) gibt es kein Touch Display: nur simulieren.
    return os.name == "nt"


def find_backlight():
    """Sucht das Backlight-Geraet: zuerst rpi_backlight, sonst das erste vorhandene."""
    try:
        names = sorted(os.listdir(BACKLIGHT_DIR))
    except OSError:
        return None
    if PREFERRED_DEVICE in names:
        names.remove(PREFERRED_DEVICE)
        names.insert(0, PREFERRED_DEVICE)
    for name in names:
        path = os.path.join(BACKLIGHT_DIR, name)
        if os.path.isfile(os.path.join(path, "brightness")):
            return path
    return None


def read_max(path):
    try:
        with open(os.path.join(path, "max_brightness")) as f:
            return int(f.read().strip())
    except (OSError, ValueError):
        return MAX_BRIGHTNESS


def apply_brightness(value):
    """Setzt die Helligkeit (50-255, wird auf den Bereich des Geraets umgerechnet).
    Gibt (ok, Meldung) zurueck."""
    value = clamp(value)
    if is_simulated():
        xbmc.log("[RPI Brightness] Test: Helligkeit %d (nicht geschrieben)" % value, xbmc.LOGINFO)
        return True, "Test"
    path = find_backlight()
    if path is None:
        message = "Kein Backlight unter %s gefunden" % BACKLIGHT_DIR
        xbmc.log("[RPI Brightness] " + message, xbmc.LOGERROR)
        return False, message
    device_max = read_max(path)
    device_value = value if device_max == MAX_BRIGHTNESS else max(1, round(value * device_max / MAX_BRIGHTNESS))
    try:
        with open(os.path.join(path, "brightness"), "w") as f:
            f.write(str(device_value))
        xbmc.log("[RPI Brightness] %s: %d (Geraet 0-%d)" % (path, device_value, device_max), xbmc.LOGINFO)
        return True, ""
    except Exception as e:
        xbmc.log("[RPI Brightness] Error setting brightness: %s" % e, xbmc.LOGERROR)
        return False, str(e)